import { DashboardLayout } from '../components/dashboard/DashboardLayout';
import { useState } from 'react';
import { 
  Wallet as WalletIcon, 
  ArrowDownLeft, 
  ArrowUpRight, 
  History, 
  CreditCard,
  Building2,
  Smartphone,
  Bitcoin,
  Copy,
  CheckCircle,
  AlertCircle,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

interface WalletProps {
  navigate: (page: string) => void;
}

const balance = {
  total: 1245.50,
  pending: 125.00,
  totalEarned: 8450.00,
  totalWithdrawn: 7205.50,
};

const transactions = [
  { id: 1, type: 'income', amount: 45, description: 'TikTok görevi onaylandı', date: '2025-01-15 14:30', status: 'completed' },
  { id: 2, type: 'income', amount: 25, description: 'Anket görevi onaylandı', date: '2025-01-15 12:15', status: 'completed' },
  { id: 3, type: 'withdraw', amount: 500, description: 'Papara\'ya çekim', date: '2025-01-14 18:45', status: 'completed' },
  { id: 4, type: 'income', amount: 120, description: 'Oyun görevi onaylandı', date: '2025-01-14 10:20', status: 'completed' },
  { id: 5, type: 'income', amount: 8, description: 'Video izleme görevi', date: '2025-01-13 16:00', status: 'completed' },
  { id: 6, type: 'withdraw', amount: 250, description: 'Banka hesabına çekim', date: '2025-01-12 09:30', status: 'completed' },
  { id: 7, type: 'income', amount: 35, description: 'Ürün inceleme görevi', date: '2025-01-11 14:00', status: 'pending' },
];

const withdrawMethods = [
  { 
    id: 'papara', 
    name: 'Papara', 
    icon: <Smartphone className="w-6 h-6" />,
    minAmount: 50,
    fee: 0,
    time: 'Anında',
    color: 'from-purple-500 to-pink-500',
  },
  { 
    id: 'bank', 
    name: 'Banka Transferi', 
    icon: <Building2 className="w-6 h-6" />,
    minAmount: 100,
    fee: 5,
    time: '1-2 iş günü',
    color: 'from-blue-500 to-cyan-500',
  },
  { 
    id: 'paypal', 
    name: 'PayPal', 
    icon: <CreditCard className="w-6 h-6" />,
    minAmount: 50,
    fee: 2,
    time: 'Anında',
    color: 'from-indigo-500 to-violet-500',
  },
  { 
    id: 'crypto', 
    name: 'Kripto (USDT)', 
    icon: <Bitcoin className="w-6 h-6" />,
    minAmount: 100,
    fee: 1,
    time: '15-30 dk',
    color: 'from-green-500 to-emerald-500',
  },
];

const depositMethods = [
  {
    id: 'bank',
    name: 'Banka Havalesi',
    description: 'Hesap numarasına havale/EFT yapın',
    icon: <Building2 className="w-6 h-6" />,
    color: 'from-blue-500 to-cyan-500',
  },
  {
    id: 'papara',
    name: 'Papara',
    description: 'Papara numarasına transfer yapın',
    icon: <Smartphone className="w-6 h-6" />,
    color: 'from-purple-500 to-pink-500',
  },
];

export default function Wallet({ navigate }: WalletProps) {
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('papara');
  const [copied, setCopied] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const selectedWithdrawMethod = withdrawMethods.find(m => m.id === selectedMethod);

  return (
    <DashboardLayout navigate={navigate} currentPage="wallet">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Bakiyem</h1>
        <p className="text-slate-400">Para çekme, yatırma ve işlem geçmişi</p>
      </div>

      {/* Balance Cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-green-500/20 to-emerald-500/10 border-green-500/30">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-green-500/20 flex items-center justify-center">
                <WalletIcon className="w-6 h-6 text-green-500" />
              </div>
              <Badge className="bg-green-500/20 text-green-400 border-0">Kullanılabilir</Badge>
            </div>
            <p className="text-sm text-slate-400 mb-1">Toplam Bakiye</p>
            <p className="text-3xl font-bold text-white">₺{balance.total.toFixed(2)}</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-white/5">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-yellow-500/20 flex items-center justify-center">
                <Clock className="w-6 h-6 text-yellow-500" />
              </div>
              <Badge className="bg-yellow-500/20 text-yellow-400 border-0">Bekliyor</Badge>
            </div>
            <p className="text-sm text-slate-400 mb-1">Onay Bekleyen</p>
            <p className="text-3xl font-bold text-white">₺{balance.pending.toFixed(2)}</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-white/5">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center">
                <ArrowDownLeft className="w-6 h-6 text-blue-500" />
              </div>
              <Badge className="bg-blue-500/20 text-blue-400 border-0">Toplam</Badge>
            </div>
            <p className="text-sm text-slate-400 mb-1">Toplam Kazanç</p>
            <p className="text-3xl font-bold text-white">₺{balance.totalEarned.toFixed(2)}</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-white/5">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                <ArrowUpRight className="w-6 h-6 text-purple-500" />
              </div>
              <Badge className="bg-purple-500/20 text-purple-400 border-0">Çekilen</Badge>
            </div>
            <p className="text-sm text-slate-400 mb-1">Toplam Çekim</p>
            <p className="text-3xl font-bold text-white">₺{balance.totalWithdrawn.toFixed(2)}</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="withdraw" className="space-y-6">
        <TabsList className="bg-slate-900/50 border border-white/5 p-1">
          <TabsTrigger value="withdraw" className="data-[state=active]:bg-green-500/20 data-[state=active]:text-green-400">
            <ArrowUpRight className="w-4 h-4 mr-2" />
            Para Çek
          </TabsTrigger>
          <TabsTrigger value="deposit" className="data-[state=active]:bg-blue-500/20 data-[state=active]:text-blue-400">
            <ArrowDownLeft className="w-4 h-4 mr-2" />
            Para Yatır
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
            <History className="w-4 h-4 mr-2" />
            İşlem Geçmişi
          </TabsTrigger>
        </TabsList>

        {/* Withdraw Tab */}
        <TabsContent value="withdraw">
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Withdraw Form */}
            <Card className="bg-slate-900/50 border-white/5">
              <CardHeader>
                <CardTitle className="text-white text-lg">Para Çekme</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Amount Input */}
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Çekilecek Tutar</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium">₺</span>
                    <Input
                      type="number"
                      placeholder="0.00"
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      className="pl-10 bg-white/5 border-white/10 text-white text-lg h-14"
                    />
                  </div>
                  <p className="text-xs text-slate-500 mt-2">
                    Minimum çekim: ₺{selectedWithdrawMethod?.minAmount}
                  </p>
                </div>

                {/* Method Selection */}
                <div>
                  <label className="text-sm text-slate-400 mb-3 block">Çekim Yöntemi</label>
                  <div className="grid grid-cols-2 gap-3">
                    {withdrawMethods.map((method) => (
                      <button
                        key={method.id}
                        onClick={() => setSelectedMethod(method.id)}
                        className={`p-4 rounded-xl border transition-all ${
                          selectedMethod === method.id
                            ? 'bg-green-500/10 border-green-500/30'
                            : 'bg-white/5 border-white/5 hover:border-white/10'
                        }`}
                      >
                        <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${method.color} flex items-center justify-center text-white mb-2`}>
                          {method.icon}
                        </div>
                        <p className="text-sm font-medium text-white">{method.name}</p>
                        <p className="text-xs text-slate-400">{method.time}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Summary */}
                <div className="p-4 rounded-xl bg-white/5 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">Çekim Tutarı</span>
                    <span className="text-white">₺{withdrawAmount || '0.00'}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">İşlem Ücreti</span>
                    <span className="text-white">₺{selectedWithdrawMethod?.fee || 0}</span>
                  </div>
                  <div className="border-t border-white/10 pt-2 flex justify-between">
                    <span className="text-slate-400">Toplam</span>
                    <span className="text-lg font-bold text-green-400">
                      ₺{Math.max(0, parseFloat(withdrawAmount || '0') - (selectedWithdrawMethod?.fee || 0)).toFixed(2)}
                    </span>
                  </div>
                </div>

                <Button 
                  className="w-full gradient-primary hover:opacity-90 text-white border-0 py-6"
                  disabled={!withdrawAmount || parseFloat(withdrawAmount) < (selectedWithdrawMethod?.minAmount || 0)}
                >
                  Para Çekme Talebi Oluştur
                </Button>
              </CardContent>
            </Card>

            {/* Info Card */}
            <Card className="bg-slate-900/50 border-white/5">
              <CardHeader>
                <CardTitle className="text-white text-lg">Çekim Bilgileri</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3 p-4 rounded-xl bg-green-500/10 border border-green-500/20">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-white">Güvenli Çekim</p>
                    <p className="text-xs text-slate-400">Tüm çekimler manuel olarak onaylanır ve 24 saat içinde işleme alınır.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 rounded-xl bg-blue-500/10 border border-blue-500/20">
                  <Clock className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-white">İşlem Süreleri</p>
                    <p className="text-xs text-slate-400">Papara ve PayPal anında, banka transferi 1-2 iş günü sürebilir.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
                  <AlertCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-white">Minimum Limit</p>
                    <p className="text-xs text-slate-400">Minimum çekim tutarı ₺50'dur. Günlük maksimum çekim limiti ₺5,000'dur.</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Deposit Tab */}
        <TabsContent value="deposit">
          <Card className="bg-slate-900/50 border-white/5 max-w-2xl">
            <CardHeader>
              <CardTitle className="text-white text-lg">Para Yatırma</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-4 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-white">Önemli Bilgi</p>
                    <p className="text-xs text-slate-400">Para yatırma işlemleri sadece görevleri hızlandırmak için kullanılır. Yatırılan tutarlar görev ödemeleri için kullanılamaz.</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-medium text-white">Yatırma Yöntemleri</h3>
                
                {depositMethods.map((method) => (
                  <Dialog key={method.id}>
                    <DialogTrigger asChild>
                      <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/10 transition-all cursor-pointer">
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${method.color} flex items-center justify-center text-white`}>
                          {method.icon}
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-white">{method.name}</p>
                          <p className="text-sm text-slate-400">{method.description}</p>
                        </div>
                        <ArrowDownLeft className="w-5 h-5 text-slate-400" />
                      </div>
                    </DialogTrigger>
                    
                    <DialogContent className="bg-slate-900 border-white/10 text-white">
                      <DialogHeader>
                        <DialogTitle className="text-white">{method.name} ile Para Yatır</DialogTitle>
                        <DialogDescription className="text-slate-400">
                          Aşağıdaki bilgileri kullanarak para yatırabilirsiniz.
                        </DialogDescription>
                      </DialogHeader>
                      
                      <div className="space-y-4 mt-4">
                        <div className="p-4 rounded-xl bg-white/5">
                          <p className="text-sm text-slate-400 mb-2">Hesap Adı</p>
                          <div className="flex items-center justify-between">
                            <p className="text-white font-medium">GörevYap Ödeme Hizmetleri A.Ş.</p>
                            <button 
                              onClick={() => handleCopy('GörevYap Ödeme Hizmetleri A.Ş.')}
                              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                            >
                              {copied ? <CheckCircle className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4 text-slate-400" />}
                            </button>
                          </div>
                        </div>
                        
                        <div className="p-4 rounded-xl bg-white/5">
                          <p className="text-sm text-slate-400 mb-2">IBAN / Hesap No</p>
                          <div className="flex items-center justify-between">
                            <p className="text-white font-medium">TR00 1234 5678 9012 3456 7890 12</p>
                            <button 
                              onClick={() => handleCopy('TR00 1234 5678 9012 3456 7890 12')}
                              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                            >
                              {copied ? <CheckCircle className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4 text-slate-400" />}
                            </button>
                          </div>
                        </div>

                        <div className="p-4 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
                          <p className="text-xs text-slate-400">
                            <strong className="text-yellow-400">Not:</strong> Açıklama kısmına kullanıcı adınızı yazmayı unutmayın. İşlem sonrası bakiyeniz 1-2 iş günü içinde yansıyacaktır.
                          </p>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history">
          <Card className="bg-slate-900/50 border-white/5">
            <CardHeader>
              <CardTitle className="text-white text-lg">İşlem Geçmişi</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {transactions.map((tx) => (
                  <div 
                    key={tx.id} 
                    className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        tx.type === 'income' ? 'bg-green-500/20' : 'bg-purple-500/20'
                      }`}>
                        {tx.type === 'income' ? (
                          <ArrowDownLeft className="w-5 h-5 text-green-500" />
                        ) : (
                          <ArrowUpRight className="w-5 h-5 text-purple-500" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium text-white">{tx.description}</p>
                        <p className="text-sm text-slate-400">{tx.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold ${tx.type === 'income' ? 'text-green-400' : 'text-purple-400'}`}>
                        {tx.type === 'income' ? '+' : '-'}₺{tx.amount}
                      </p>
                      <Badge className={`text-xs ${
                        tx.status === 'completed' 
                          ? 'bg-green-500/20 text-green-400' 
                          : 'bg-yellow-500/20 text-yellow-400'
                      }`}>
                        {tx.status === 'completed' ? 'Tamamlandı' : 'Bekliyor'}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  );
}
