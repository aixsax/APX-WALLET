import { AdminLayout } from '../../components/admin/AdminLayout';
import { useState } from 'react';
import { 
  Image,
  Type,
  Palette,
  Save,
  RefreshCw,
  CheckCircle,
  DollarSign,
  Users,
  Shield,
  Bell,
  Mail
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';

interface AdminSettingsProps {
  navigate: (page: string) => void;
}

export default function AdminSettings({ navigate }: AdminSettingsProps) {
  const [settings, setSettings] = useState({
    // Brand Settings
    siteName: 'GörevYap',
    siteTagline: 'Görev Yap, Para Kazan',
    logoUrl: '',
    faviconUrl: '',
    primaryColor: '#22c55e',
    
    // Payment Settings
    minWithdrawal: 50,
    maxWithdrawalDaily: 5000,
    paparaEnabled: true,
    bankEnabled: true,
    paypalEnabled: true,
    cryptoEnabled: false,
    
    // User Settings
    registrationEnabled: true,
    emailVerification: true,
    referralBonus: 10,
    welcomeBonus: 10,
    
    // Notification Settings
    emailNotifications: true,
    adminNotifications: true,
    newUserAlert: true,
    withdrawalAlert: true,
    
    // Security Settings
    twoFactorAuth: false,
    ipRestriction: false,
    loginAttempts: 5,
  });

  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleReset = () => {
    if (confirm('Tüm ayarları varsayılana sıfırlamak istediğinize emin misiniz?')) {
      setSettings({
        siteName: 'GörevYap',
        siteTagline: 'Görev Yap, Para Kazan',
        logoUrl: '',
        faviconUrl: '',
        primaryColor: '#22c55e',
        minWithdrawal: 50,
        maxWithdrawalDaily: 5000,
        paparaEnabled: true,
        bankEnabled: true,
        paypalEnabled: true,
        cryptoEnabled: false,
        registrationEnabled: true,
        emailVerification: true,
        referralBonus: 10,
        welcomeBonus: 10,
        emailNotifications: true,
        adminNotifications: true,
        newUserAlert: true,
        withdrawalAlert: true,
        twoFactorAuth: false,
        ipRestriction: false,
        loginAttempts: 5,
      });
    }
  };

  return (
    <AdminLayout navigate={navigate} currentPage="admin-settings">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white mb-2">Site Ayarları</h1>
          <p className="text-slate-400">Platform ayarlarını özelleştir</p>
        </div>
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            onClick={handleReset}
            className="border-white/10 text-slate-300 hover:bg-white/5"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Sıfırla
          </Button>
          <Button 
            onClick={handleSave}
            className="bg-red-500 hover:bg-red-600 text-white"
          >
            {saved ? (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                Kaydedildi
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Kaydet
              </>
            )}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="brand" className="space-y-6">
        <TabsList className="bg-slate-900/50 border border-white/5 p-1 flex-wrap">
          <TabsTrigger value="brand" className="data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400">
            <Image className="w-4 h-4 mr-2" />
            Marka
          </TabsTrigger>
          <TabsTrigger value="payment" className="data-[state=active]:bg-green-500/20 data-[state=active]:text-green-400">
            <DollarSign className="w-4 h-4 mr-2" />
            Ödeme
          </TabsTrigger>
          <TabsTrigger value="users" className="data-[state=active]:bg-blue-500/20 data-[state=active]:text-blue-400">
            <Users className="w-4 h-4 mr-2" />
            Kullanıcı
          </TabsTrigger>
          <TabsTrigger value="notifications" className="data-[state=active]:bg-yellow-500/20 data-[state=active]:text-yellow-400">
            <Bell className="w-4 h-4 mr-2" />
            Bildirim
          </TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
            <Shield className="w-4 h-4 mr-2" />
            Güvenlik
          </TabsTrigger>
        </TabsList>

        {/* Brand Settings */}
        <TabsContent value="brand">
          <Card className="bg-slate-900/50 border-white/5">
            <CardHeader>
              <CardTitle className="text-white text-lg flex items-center gap-2">
                <Palette className="w-5 h-5 text-red-500" />
                Marka Ayarları
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Site Adı</label>
                  <Input
                    value={settings.siteName}
                    onChange={(e) => setSettings({...settings, siteName: e.target.value})}
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Slogan</label>
                  <Input
                    value={settings.siteTagline}
                    onChange={(e) => setSettings({...settings, siteTagline: e.target.value})}
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Logo URL</label>
                  <Input
                    value={settings.logoUrl}
                    onChange={(e) => setSettings({...settings, logoUrl: e.target.value})}
                    className="bg-white/5 border-white/10 text-white"
                    placeholder="https://..."
                  />
                  <p className="text-xs text-slate-500 mt-1">Önerilen boyut: 200x50px</p>
                </div>
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Favicon URL</label>
                  <Input
                    value={settings.faviconUrl}
                    onChange={(e) => setSettings({...settings, faviconUrl: e.target.value})}
                    className="bg-white/5 border-white/10 text-white"
                    placeholder="https://..."
                  />
                  <p className="text-xs text-slate-500 mt-1">Önerilen boyut: 32x32px</p>
                </div>
              </div>

              <div>
                <label className="text-sm text-slate-400 mb-2 block">Ana Renk</label>
                <div className="flex items-center gap-4">
                  <input
                    type="color"
                    value={settings.primaryColor}
                    onChange={(e) => setSettings({...settings, primaryColor: e.target.value})}
                    className="w-16 h-10 rounded-lg bg-transparent border border-white/10"
                  />
                  <Input
                    value={settings.primaryColor}
                    onChange={(e) => setSettings({...settings, primaryColor: e.target.value})}
                    className="w-32 bg-white/5 border-white/10 text-white"
                  />
                </div>
              </div>

              {/* Preview */}
              <div className="p-6 rounded-xl bg-slate-800/50 border border-white/5">
                <p className="text-sm text-slate-400 mb-4">Önizleme</p>
                <div className="flex items-center gap-4">
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{ backgroundColor: settings.primaryColor }}
                  >
                    <Type className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-xl font-bold text-white">{settings.siteName}</p>
                    <p className="text-sm text-slate-400">{settings.siteTagline}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payment Settings */}
        <TabsContent value="payment">
          <Card className="bg-slate-900/50 border-white/5">
            <CardHeader>
              <CardTitle className="text-white text-lg flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-green-500" />
                Ödeme Ayarları
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Minimum Çekim (₺)</label>
                  <Input
                    type="number"
                    value={settings.minWithdrawal}
                    onChange={(e) => setSettings({...settings, minWithdrawal: parseInt(e.target.value)})}
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Günlük Maksimum Çekim (₺)</label>
                  <Input
                    type="number"
                    value={settings.maxWithdrawalDaily}
                    onChange={(e) => setSettings({...settings, maxWithdrawalDaily: parseInt(e.target.value)})}
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm text-slate-400 mb-4 block">Ödeme Yöntemleri</label>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                        <DollarSign className="w-5 h-5 text-purple-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">Papara</p>
                        <p className="text-sm text-slate-400">Anında çekim</p>
                      </div>
                    </div>
                    <Switch 
                      checked={settings.paparaEnabled}
                      onCheckedChange={(checked) => setSettings({...settings, paparaEnabled: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                        <DollarSign className="w-5 h-5 text-blue-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">Banka Transferi</p>
                        <p className="text-sm text-slate-400">1-2 iş günü</p>
                      </div>
                    </div>
                    <Switch 
                      checked={settings.bankEnabled}
                      onCheckedChange={(checked) => setSettings({...settings, bankEnabled: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-indigo-500/20 flex items-center justify-center">
                        <DollarSign className="w-5 h-5 text-indigo-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">PayPal</p>
                        <p className="text-sm text-slate-400">Anında çekim</p>
                      </div>
                    </div>
                    <Switch 
                      checked={settings.paypalEnabled}
                      onCheckedChange={(checked) => setSettings({...settings, paypalEnabled: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                        <DollarSign className="w-5 h-5 text-green-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">Kripto (USDT)</p>
                        <p className="text-sm text-slate-400">15-30 dakika</p>
                      </div>
                    </div>
                    <Switch 
                      checked={settings.cryptoEnabled}
                      onCheckedChange={(checked) => setSettings({...settings, cryptoEnabled: checked})}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* User Settings */}
        <TabsContent value="users">
          <Card className="bg-slate-900/50 border-white/5">
            <CardHeader>
              <CardTitle className="text-white text-lg flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-500" />
                Kullanıcı Ayarları
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                    <Users className="w-5 h-5 text-green-500" />
                  </div>
                  <div>
                    <p className="font-medium text-white">Yeni Kayıtlar</p>
                    <p className="text-sm text-slate-400">Yeni kullanıcı kayıtlarını aç/kapat</p>
                  </div>
                </div>
                <Switch 
                  checked={settings.registrationEnabled}
                  onCheckedChange={(checked) => setSettings({...settings, registrationEnabled: checked})}
                />
              </div>

              <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                    <Mail className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="font-medium text-white">E-posta Doğrulama</p>
                    <p className="text-sm text-slate-400">Kayıtta e-posta doğrulaması zorunlu</p>
                  </div>
                </div>
                <Switch 
                  checked={settings.emailVerification}
                  onCheckedChange={(checked) => setSettings({...settings, emailVerification: checked})}
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Hoş Geldin Bonusu (₺)</label>
                  <Input
                    type="number"
                    value={settings.welcomeBonus}
                    onChange={(e) => setSettings({...settings, welcomeBonus: parseInt(e.target.value)})}
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Referans Bonusu (₺)</label>
                  <Input
                    type="number"
                    value={settings.referralBonus}
                    onChange={(e) => setSettings({...settings, referralBonus: parseInt(e.target.value)})}
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notification Settings */}
        <TabsContent value="notifications">
          <Card className="bg-slate-900/50 border-white/5">
            <CardHeader>
              <CardTitle className="text-white text-lg flex items-center gap-2">
                <Bell className="w-5 h-5 text-yellow-500" />
                Bildirim Ayarları
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                    <Mail className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="font-medium text-white">E-posta Bildirimleri</p>
                    <p className="text-sm text-slate-400">Kullanıcılara e-posta gönder</p>
                  </div>
                </div>
                <Switch 
                  checked={settings.emailNotifications}
                  onCheckedChange={(checked) => setSettings({...settings, emailNotifications: checked})}
                />
              </div>

              <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-red-500/20 flex items-center justify-center">
                    <Bell className="w-5 h-5 text-red-500" />
                  </div>
                  <div>
                    <p className="font-medium text-white">Admin Bildirimleri</p>
                    <p className="text-sm text-slate-400">Yönetici paneli bildirimleri</p>
                  </div>
                </div>
                <Switch 
                  checked={settings.adminNotifications}
                  onCheckedChange={(checked) => setSettings({...settings, adminNotifications: checked})}
                />
              </div>

              <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                    <Users className="w-5 h-5 text-green-500" />
                  </div>
                  <div>
                    <p className="font-medium text-white">Yeni Kullanıcı Uyarısı</p>
                    <p className="text-sm text-slate-400">Yeni kayıt olduğunda bildir</p>
                  </div>
                </div>
                <Switch 
                  checked={settings.newUserAlert}
                  onCheckedChange={(checked) => setSettings({...settings, newUserAlert: checked})}
                />
              </div>

              <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-yellow-500/20 flex items-center justify-center">
                    <DollarSign className="w-5 h-5 text-yellow-500" />
                  </div>
                  <div>
                    <p className="font-medium text-white">Çekim Talebi Uyarısı</p>
                    <p className="text-sm text-slate-400">Para çekme talebi geldiğinde bildir</p>
                  </div>
                </div>
                <Switch 
                  checked={settings.withdrawalAlert}
                  onCheckedChange={(checked) => setSettings({...settings, withdrawalAlert: checked})}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security">
          <Card className="bg-slate-900/50 border-white/5">
            <CardHeader>
              <CardTitle className="text-white text-lg flex items-center gap-2">
                <Shield className="w-5 h-5 text-purple-500" />
                Güvenlik Ayarları
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                    <Shield className="w-5 h-5 text-green-500" />
                  </div>
                  <div>
                    <p className="font-medium text-white">İki Faktörlü Doğrulama</p>
                    <p className="text-sm text-slate-400">Admin paneli için 2FA zorunlu</p>
                  </div>
                </div>
                <Switch 
                  checked={settings.twoFactorAuth}
                  onCheckedChange={(checked) => setSettings({...settings, twoFactorAuth: checked})}
                />
              </div>

              <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                    <Shield className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="font-medium text-white">IP Kısıtlaması</p>
                    <p className="text-sm text-slate-400">Sadece belirli IP adreslerinden erişim</p>
                  </div>
                </div>
                <Switch 
                  checked={settings.ipRestriction}
                  onCheckedChange={(checked) => setSettings({...settings, ipRestriction: checked})}
                />
              </div>

              <div>
                <label className="text-sm text-slate-400 mb-2 block">Maksimum Giriş Denemesi</label>
                <Input
                  type="number"
                  value={settings.loginAttempts}
                  onChange={(e) => setSettings({...settings, loginAttempts: parseInt(e.target.value)})}
                  className="bg-white/5 border-white/10 text-white w-32"
                />
                <p className="text-xs text-slate-500 mt-1">Başarısız giriş denemesi sonrası hesap kilitlenir</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </AdminLayout>
  );
}
