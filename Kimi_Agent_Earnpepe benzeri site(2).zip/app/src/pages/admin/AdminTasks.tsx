import { AdminLayout } from '../../components/admin/AdminLayout';
import { useState } from 'react';
import { 
  Search, 
  Plus, 
  Edit2, 
  Trash2, 
  Eye,
  CheckCircle,
  TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';


interface AdminTasksProps {
  navigate: (page: string) => void;
}

const categories = ['Tümü', 'Anket', 'Uygulama', 'Video', 'Sosyal Medya', 'Oyun', 'Kayıt'];

const initialTasks = [
  {
    id: 1,
    title: 'TikTok Uygulamasını İndir ve 3 Gün Kullan',
    category: 'Uygulama',
    reward: 45,
    duration: '3 gün',
    status: 'active',
    applications: 2340,
    completions: 1890,
    featured: true,
    description: 'TikTok uygulamasını indir, hesap oluştur ve 3 gün boyunca kullan.',
    requirements: ['Android 8.0+ veya iOS 13+', 'Yeni hesap oluşturma'],
  },
  {
    id: 2,
    title: 'Market Araştırması Anketi',
    category: 'Anket',
    reward: 25,
    duration: '10 dk',
    status: 'active',
    applications: 5670,
    completions: 4230,
    featured: false,
    description: 'Alışveriş alışkanlıklarınız hakkında kısa bir anket doldurun.',
    requirements: ['18 yaş üzeri', 'Türkiye\'de ikamet'],
  },
  {
    id: 3,
    title: 'YouTube Videosu İzle ve Beğen',
    category: 'Video',
    reward: 8,
    duration: '5 dk',
    status: 'active',
    applications: 8900,
    completions: 7560,
    featured: false,
    description: 'Belirtilen videoyu izleyin ve beğenin.',
    requirements: ['YouTube hesabı'],
  },
  {
    id: 4,
    title: 'Instagram Hesabını Takip Et',
    category: 'Sosyal Medya',
    reward: 5,
    duration: '1 dk',
    status: 'inactive',
    applications: 12300,
    completions: 11000,
    featured: false,
    description: 'Belirtilen hesabı takip edin.',
    requirements: ['Instagram hesabı'],
  },
  {
    id: 5,
    title: 'Mobil Oyun - Seviye 10\'a Ulaş',
    category: 'Oyun',
    reward: 120,
    duration: '2-3 gün',
    status: 'active',
    applications: 890,
    completions: 450,
    featured: true,
    description: 'Oyunu indir ve seviye 10\'a ulaş.',
    requirements: ['Android veya iOS'],
  },
];

export default function AdminTasks({ navigate }: AdminTasksProps) {
  const [tasks, setTasks] = useState(initialTasks);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('Tümü');
  const [editingTask, setEditingTask] = useState<any>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newTask, setNewTask] = useState({
    title: '',
    category: 'Anket',
    reward: '',
    duration: '',
    description: '',
    requirements: '',
    featured: false,
  });

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'Tümü' || task.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const handleDelete = (id: number) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const handleToggleStatus = (id: number) => {
    setTasks(tasks.map(t => 
      t.id === id ? { ...t, status: t.status === 'active' ? 'inactive' : 'active' } : t
    ));
  };

  const handleAddTask = () => {
    const task = {
      id: tasks.length + 1,
      title: newTask.title,
      category: newTask.category,
      reward: parseInt(newTask.reward) || 0,
      duration: newTask.duration,
      status: 'active',
      applications: 0,
      completions: 0,
      featured: newTask.featured,
      description: newTask.description,
      requirements: newTask.requirements.split(',').map(r => r.trim()),
    };
    setTasks([...tasks, task]);
    setIsAddDialogOpen(false);
    setNewTask({
      title: '',
      category: 'Anket',
      reward: '',
      duration: '',
      description: '',
      requirements: '',
      featured: false,
    });
  };

  const handleUpdateTask = () => {
    setTasks(tasks.map(t => 
      t.id === editingTask.id ? editingTask : t
    ));
    setEditingTask(null);
  };

  return (
    <AdminLayout navigate={navigate} currentPage="admin-tasks">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white mb-2">Görev Yönetimi</h1>
          <p className="text-slate-400">Görevleri ekle, düzenle ve yönet</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-red-500 hover:bg-red-600 text-white">
              <Plus className="w-4 h-4 mr-2" />
              Yeni Görev Ekle
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-900 border-white/10 text-white max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white">Yeni Görev Ekle</DialogTitle>
              <DialogDescription className="text-slate-400">
                Yeni bir görev oluşturun
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div>
                <label className="text-sm text-slate-400 mb-2 block">Görev Başlığı</label>
                <Input
                  value={newTask.title}
                  onChange={(e) => setNewTask({...newTask, title: e.target.value})}
                  className="bg-white/5 border-white/10 text-white"
                  placeholder="Örn: TikTok Uygulaması İndir"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Kategori</label>
                  <select
                    value={newTask.category}
                    onChange={(e) => setNewTask({...newTask, category: e.target.value})}
                    className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white"
                  >
                    {categories.filter(c => c !== 'Tümü').map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Ödül (₺)</label>
                  <Input
                    type="number"
                    value={newTask.reward}
                    onChange={(e) => setNewTask({...newTask, reward: e.target.value})}
                    className="bg-white/5 border-white/10 text-white"
                    placeholder="25"
                  />
                </div>
              </div>
              <div>
                <label className="text-sm text-slate-400 mb-2 block">Süre</label>
                <Input
                  value={newTask.duration}
                  onChange={(e) => setNewTask({...newTask, duration: e.target.value})}
                  className="bg-white/5 border-white/10 text-white"
                  placeholder="Örn: 10 dk"
                />
              </div>
              <div>
                <label className="text-sm text-slate-400 mb-2 block">Açıklama</label>
                <textarea
                  value={newTask.description}
                  onChange={(e) => setNewTask({...newTask, description: e.target.value})}
                  className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white resize-none"
                  rows={3}
                  placeholder="Görev açıklaması..."
                />
              </div>
              <div>
                <label className="text-sm text-slate-400 mb-2 block">Gereksinimler (virgülle ayırın)</label>
                <Input
                  value={newTask.requirements}
                  onChange={(e) => setNewTask({...newTask, requirements: e.target.value})}
                  className="bg-white/5 border-white/10 text-white"
                  placeholder="Android 8.0+, Yeni hesap"
                />
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="featured"
                  checked={newTask.featured}
                  onChange={(e) => setNewTask({...newTask, featured: e.target.checked})}
                  className="w-4 h-4 rounded border-white/10 bg-white/5"
                />
                <label htmlFor="featured" className="text-sm text-slate-300">Öne Çıkan Görev</label>
              </div>
            </div>
            <DialogFooter className="mt-6">
              <DialogClose asChild>
                <Button variant="outline" className="border-white/10 text-white hover:bg-white/5">
                  İptal
                </Button>
              </DialogClose>
              <Button onClick={handleAddTask} className="bg-red-500 hover:bg-red-600 text-white">
                Görev Ekle
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card className="bg-slate-900/50 border-white/5 mb-6">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <Input
                type="text"
                placeholder="Görev ara..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white/5 border-white/10 text-white"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${
                    activeCategory === cat
                      ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                      : 'bg-white/5 text-slate-400 border border-white/5 hover:border-white/10'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tasks Table */}
      <Card className="bg-slate-900/50 border-white/5">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  <th className="text-left py-4 px-6 text-sm font-medium text-slate-400">Görev</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Kategori</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Ödül</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Başvuru</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Tamamlama</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Durum</th>
                  <th className="text-right py-4 px-6 text-sm font-medium text-slate-400">İşlemler</th>
                </tr>
              </thead>
              <tbody>
                {filteredTasks.map((task) => (
                  <tr key={task.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        {task.featured && <TrendingUp className="w-4 h-4 text-yellow-500" />}
                        <span className="text-white font-medium">{task.title}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <Badge className="bg-white/5 text-slate-300 border-0">{task.category}</Badge>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className="text-green-400 font-medium">₺{task.reward}</span>
                    </td>
                    <td className="py-4 px-4 text-center text-slate-300">{task.applications.toLocaleString()}</td>
                    <td className="py-4 px-4 text-center text-slate-300">{task.completions.toLocaleString()}</td>
                    <td className="py-4 px-4 text-center">
                      <button
                        onClick={() => handleToggleStatus(task.id)}
                        className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                          task.status === 'active'
                            ? 'bg-green-500/20 text-green-400'
                            : 'bg-red-500/20 text-red-400'
                        }`}
                      >
                        {task.status === 'active' ? 'Aktif' : 'Pasif'}
                      </button>
                    </td>
                    <td className="py-4 px-6 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="sm" variant="ghost" className="text-slate-400 hover:text-white">
                              <Eye className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="bg-slate-900 border-white/10 text-white">
                            <DialogHeader>
                              <DialogTitle className="text-white">{task.title}</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4 mt-4">
                              <p className="text-slate-400">{task.description}</p>
                              <div className="grid grid-cols-2 gap-4">
                                <div className="p-3 rounded-xl bg-white/5">
                                  <p className="text-xs text-slate-400">Ödül</p>
                                  <p className="text-lg font-bold text-green-400">₺{task.reward}</p>
                                </div>
                                <div className="p-3 rounded-xl bg-white/5">
                                  <p className="text-xs text-slate-400">Süre</p>
                                  <p className="text-lg font-bold text-white">{task.duration}</p>
                                </div>
                              </div>
                              <div>
                                <p className="text-sm text-slate-400 mb-2">Gereksinimler:</p>
                                <ul className="space-y-1">
                                  {task.requirements.map((req, idx) => (
                                    <li key={idx} className="text-sm text-slate-300 flex items-center gap-2">
                                      <CheckCircle className="w-4 h-4 text-green-500" />
                                      {req}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>

                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              className="text-blue-400 hover:text-blue-300"
                              onClick={() => setEditingTask(task)}
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="bg-slate-900 border-white/10 text-white max-w-lg max-h-[90vh] overflow-y-auto">
                            <DialogHeader>
                              <DialogTitle className="text-white">Görev Düzenle</DialogTitle>
                            </DialogHeader>
                            {editingTask && (
                              <div className="space-y-4 mt-4">
                                <div>
                                  <label className="text-sm text-slate-400 mb-2 block">Başlık</label>
                                  <Input
                                    value={editingTask.title}
                                    onChange={(e) => setEditingTask({...editingTask, title: e.target.value})}
                                    className="bg-white/5 border-white/10 text-white"
                                  />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <label className="text-sm text-slate-400 mb-2 block">Ödül (₺)</label>
                                    <Input
                                      type="number"
                                      value={editingTask.reward}
                                      onChange={(e) => setEditingTask({...editingTask, reward: parseInt(e.target.value)})}
                                      className="bg-white/5 border-white/10 text-white"
                                    />
                                  </div>
                                  <div>
                                    <label className="text-sm text-slate-400 mb-2 block">Süre</label>
                                    <Input
                                      value={editingTask.duration}
                                      onChange={(e) => setEditingTask({...editingTask, duration: e.target.value})}
                                      className="bg-white/5 border-white/10 text-white"
                                    />
                                  </div>
                                </div>
                              </div>
                            )}
                            <DialogFooter className="mt-6">
                              <DialogClose asChild>
                                <Button variant="outline" className="border-white/10 text-white hover:bg-white/5">
                                  İptal
                                </Button>
                              </DialogClose>
                              <Button onClick={handleUpdateTask} className="bg-blue-500 hover:bg-blue-600 text-white">
                                Kaydet
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>

                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="text-red-400 hover:text-red-300"
                          onClick={() => handleDelete(task.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </AdminLayout>
  );
}
