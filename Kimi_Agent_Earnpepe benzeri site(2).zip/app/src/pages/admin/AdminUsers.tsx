import { AdminLayout } from '../../components/admin/AdminLayout';
import { useState } from 'react';
import { 
  Search, 
  Phone,
  Wallet,
  CheckCircle,
  Ban,
  Eye,
  TrendingUp,
  Calendar,
  MoreVertical
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface AdminUsersProps {
  navigate: (page: string) => void;
}

const initialUsers = [
  {
    id: 1,
    name: 'Ahmet Yılmaz',
    email: 'ahmet@email.com',
    phone: '+90 555 123 45 67',
    status: 'active',
    balance: 1245.50,
    totalEarned: 8450.00,
    tasksCompleted: 156,
    joinDate: '2024-08-15',
    lastActive: '2025-01-15 14:30',
    level: 12,
  },
  {
    id: 2,
    name: 'Zeynep Kaya',
    email: 'zeynep@email.com',
    phone: '+90 555 234 56 78',
    status: 'active',
    balance: 890.00,
    totalEarned: 5230.00,
    tasksCompleted: 98,
    joinDate: '2024-09-20',
    lastActive: '2025-01-15 13:15',
    level: 8,
  },
  {
    id: 3,
    name: 'Mehmet Demir',
    email: 'mehmet@email.com',
    phone: '+90 555 345 67 89',
    status: 'suspended',
    balance: 0,
    totalEarned: 1200.00,
    tasksCompleted: 45,
    joinDate: '2024-10-05',
    lastActive: '2025-01-10 09:00',
    level: 5,
  },
  {
    id: 4,
    name: 'Elif Şahin',
    email: 'elif@email.com',
    phone: '+90 555 456 78 90',
    status: 'active',
    balance: 2340.00,
    totalEarned: 12500.00,
    tasksCompleted: 234,
    joinDate: '2024-07-12',
    lastActive: '2025-01-15 15:00',
    level: 15,
  },
  {
    id: 5,
    name: 'Can Özdemir',
    email: 'can@email.com',
    phone: '+90 555 567 89 01',
    status: 'pending',
    balance: 0,
    totalEarned: 0,
    tasksCompleted: 0,
    joinDate: '2025-01-15',
    lastActive: '2025-01-15 10:30',
    level: 1,
  },
];

export default function AdminUsers({ navigate }: AdminUsersProps) {
  const [users, setUsers] = useState(initialUsers);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedUser, setSelectedUser] = useState<any>(null);

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         user.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || user.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleToggleStatus = (id: number, newStatus: string) => {
    setUsers(users.map(u => u.id === id ? { ...u, status: newStatus } : u));
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-500/20 text-green-400 border-0">Aktif</Badge>;
      case 'suspended':
        return <Badge className="bg-red-500/20 text-red-400 border-0">Askıya Alındı</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-0">Bekliyor</Badge>;
      default:
        return <Badge className="bg-slate-500/20 text-slate-400 border-0">Bilinmiyor</Badge>;
    }
  };

  return (
    <AdminLayout navigate={navigate} currentPage="admin-users">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Kullanıcı Yönetimi</h1>
        <p className="text-slate-400">Kullanıcıları görüntüle, düzenle ve yönet</p>
      </div>

      {/* Stats */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card className="bg-slate-900/50 border-white/5">
          <CardContent className="p-4">
            <p className="text-sm text-slate-400">Toplam Kullanıcı</p>
            <p className="text-2xl font-bold text-white">{users.length.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-900/50 border-white/5">
          <CardContent className="p-4">
            <p className="text-sm text-slate-400">Aktif Kullanıcı</p>
            <p className="text-2xl font-bold text-green-400">{users.filter(u => u.status === 'active').length.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-900/50 border-white/5">
          <CardContent className="p-4">
            <p className="text-sm text-slate-400">Bekleyen</p>
            <p className="text-2xl font-bold text-yellow-400">{users.filter(u => u.status === 'pending').length.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-900/50 border-white/5">
          <CardContent className="p-4">
            <p className="text-sm text-slate-400">Askıya Alınan</p>
            <p className="text-2xl font-bold text-red-400">{users.filter(u => u.status === 'suspended').length.toLocaleString()}</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="bg-slate-900/50 border-white/5 mb-6">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <Input
                type="text"
                placeholder="Kullanıcı ara..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white/5 border-white/10 text-white"
              />
            </div>
            <div className="flex gap-2">
              {[
                { id: 'all', label: 'Tümü' },
                { id: 'active', label: 'Aktif' },
                { id: 'pending', label: 'Bekliyor' },
                { id: 'suspended', label: 'Askıda' },
              ].map((status) => (
                <button
                  key={status.id}
                  onClick={() => setStatusFilter(status.id)}
                  className={`px-4 py-2 rounded-xl transition-all ${
                    statusFilter === status.id
                      ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                      : 'bg-white/5 text-slate-400 border border-white/5 hover:border-white/10'
                  }`}
                >
                  {status.label}
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card className="bg-slate-900/50 border-white/5">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  <th className="text-left py-4 px-6 text-sm font-medium text-slate-400">Kullanıcı</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">İletişim</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Bakiye</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Kazanç</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Görev</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Durum</th>
                  <th className="text-right py-4 px-6 text-sm font-medium text-slate-400">İşlemler</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white font-bold text-sm">
                          {user.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <p className="font-medium text-white">{user.name}</p>
                          <p className="text-xs text-slate-400">Seviye {user.level} • {user.joinDate}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <div className="text-center">
                        <p className="text-sm text-slate-300">{user.email}</p>
                        <p className="text-xs text-slate-400">{user.phone}</p>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className="text-green-400 font-medium">₺{user.balance.toFixed(2)}</span>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className="text-blue-400 font-medium">₺{user.totalEarned.toFixed(2)}</span>
                    </td>
                    <td className="py-4 px-4 text-center text-slate-300">{user.tasksCompleted}</td>
                    <td className="py-4 px-4 text-center">
                      {getStatusBadge(user.status)}
                    </td>
                    <td className="py-4 px-6 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              className="text-slate-400 hover:text-white"
                              onClick={() => setSelectedUser(user)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="bg-slate-900 border-white/10 text-white max-w-lg">
                            <DialogHeader>
                              <DialogTitle className="text-white">Kullanıcı Detayları</DialogTitle>
                            </DialogHeader>
                            {selectedUser && (
                              <div className="space-y-6 mt-4">
                                <div className="flex items-center gap-4">
                                  <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white font-bold text-xl">
                                    {selectedUser.name.split(' ').map((n: string) => n[0]).join('')}
                                  </div>
                                  <div>
                                    <p className="text-xl font-bold text-white">{selectedUser.name}</p>
                                    <p className="text-slate-400">{selectedUser.email}</p>
                                    <div className="flex items-center gap-2 mt-1">
                                      {getStatusBadge(selectedUser.status)}
                                      <Badge className="bg-yellow-500/20 text-yellow-400 border-0">
                                        Seviye {selectedUser.level}
                                      </Badge>
                                    </div>
                                  </div>
                                </div>

                                <div className="grid grid-cols-3 gap-4">
                                  <div className="p-4 rounded-xl bg-white/5 text-center">
                                    <Wallet className="w-5 h-5 text-green-500 mx-auto mb-2" />
                                    <p className="text-xs text-slate-400">Bakiye</p>
                                    <p className="text-lg font-bold text-green-400">₺{selectedUser.balance.toFixed(2)}</p>
                                  </div>
                                  <div className="p-4 rounded-xl bg-white/5 text-center">
                                    <TrendingUp className="w-5 h-5 text-blue-500 mx-auto mb-2" />
                                    <p className="text-xs text-slate-400">Toplam Kazanç</p>
                                    <p className="text-lg font-bold text-blue-400">₺{selectedUser.totalEarned.toFixed(2)}</p>
                                  </div>
                                  <div className="p-4 rounded-xl bg-white/5 text-center">
                                    <CheckCircle className="w-5 h-5 text-purple-500 mx-auto mb-2" />
                                    <p className="text-xs text-slate-400">Tamamlanan</p>
                                    <p className="text-lg font-bold text-purple-400">{selectedUser.tasksCompleted}</p>
                                  </div>
                                </div>

                                <div className="space-y-2">
                                  <div className="flex items-center gap-2 text-sm">
                                    <Phone className="w-4 h-4 text-slate-400" />
                                    <span className="text-slate-300">{selectedUser.phone}</span>
                                  </div>
                                  <div className="flex items-center gap-2 text-sm">
                                    <Calendar className="w-4 h-4 text-slate-400" />
                                    <span className="text-slate-300">Kayıt: {selectedUser.joinDate}</span>
                                  </div>
                                  <div className="flex items-center gap-2 text-sm">
                                    <Calendar className="w-4 h-4 text-slate-400" />
                                    <span className="text-slate-300">Son Aktif: {selectedUser.lastActive}</span>
                                  </div>
                                </div>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>

                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button size="sm" variant="ghost" className="text-slate-400 hover:text-white">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="bg-slate-900 border-white/10">
                            {user.status !== 'active' && (
                              <DropdownMenuItem 
                                onClick={() => handleToggleStatus(user.id, 'active')}
                                className="text-green-400 cursor-pointer"
                              >
                                <CheckCircle className="w-4 h-4 mr-2" />
                                Aktifleştir
                              </DropdownMenuItem>
                            )}
                            {user.status !== 'suspended' && (
                              <DropdownMenuItem 
                                onClick={() => handleToggleStatus(user.id, 'suspended')}
                                className="text-red-400 cursor-pointer"
                              >
                                <Ban className="w-4 h-4 mr-2" />
                                Askıya Al
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </AdminLayout>
  );
}
