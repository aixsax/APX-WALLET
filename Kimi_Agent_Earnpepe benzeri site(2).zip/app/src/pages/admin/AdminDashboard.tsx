import { AdminLayout } from '../../components/admin/AdminLayout';
import { 
  Users, 
  ListTodo, 
  Wallet, 
  ArrowUpRight,
  ArrowDownRight,
  DollarSign,
  CheckCircle,
  Clock,
  AlertCircle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface AdminDashboardProps {
  navigate: (page: string) => void;
}

const stats = [
  {
    title: 'Toplam Kullanıcı',
    value: '12,456',
    change: '+156 bu ay',
    icon: <Users className="w-5 h-5" />,
    trend: 'up',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    title: 'Aktif Görevler',
    value: '3,847',
    change: '+45 yeni',
    icon: <ListTodo className="w-5 h-5" />,
    trend: 'up',
    color: 'from-green-500 to-emerald-500',
  },
  {
    title: 'Toplam Ödeme',
    value: '₺2.5M',
    change: '+₺125K bu ay',
    icon: <Wallet className="w-5 h-5" />,
    trend: 'up',
    color: 'from-purple-500 to-pink-500',
  },
  {
    title: 'Bekleyen Çekim',
    value: '₺45,230',
    change: '12 talep',
    icon: <Clock className="w-5 h-5" />,
    trend: 'neutral',
    color: 'from-orange-500 to-red-500',
  },
];

const recentUsers = [
  { id: 1, name: 'Mehmet Kaya', email: 'mehmet@email.com', date: '2025-01-15 14:30', status: 'active', balance: 1250 },
  { id: 2, name: 'Zeynep Demir', email: 'zeynep@email.com', date: '2025-01-15 13:15', status: 'active', balance: 890 },
  { id: 3, name: 'Can Yılmaz', email: 'can@email.com', date: '2025-01-15 12:00', status: 'pending', balance: 0 },
  { id: 4, name: 'Elif Şahin', email: 'elif@email.com', date: '2025-01-15 10:45', status: 'active', balance: 2340 },
];

const pendingWithdrawals = [
  { id: 1, user: 'Ahmet Yılmaz', amount: 500, method: 'Papara', date: '2025-01-15 14:30' },
  { id: 2, user: 'Zeynep Kaya', amount: 1200, method: 'Banka', date: '2025-01-15 13:00' },
  { id: 3, user: 'Mehmet Demir', amount: 350, method: 'PayPal', date: '2025-01-15 11:30' },
];

const recentTasks = [
  { id: 1, title: 'TikTok İndirme', applications: 234, completions: 189, reward: 45 },
  { id: 2, title: 'Market Anketi', applications: 567, completions: 423, reward: 25 },
  { id: 3, title: 'YouTube Video', applications: 890, completions: 756, reward: 8 },
];

export default function AdminDashboard({ navigate }: AdminDashboardProps) {
  return (
    <AdminLayout navigate={navigate} currentPage="admin">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Admin Dashboard</h1>
        <p className="text-slate-400">Platformun genel durumu ve istatistikleri</p>
      </div>

      {/* Stats Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <Card key={index} className="bg-slate-900/50 border-white/5 hover:border-red-500/30 transition-all">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-slate-400 mb-1">{stat.title}</p>
                  <p className="text-2xl font-bold text-white">{stat.value}</p>
                  <div className="flex items-center gap-1 mt-2">
                    {stat.trend === 'up' && <ArrowUpRight className="w-4 h-4 text-green-500" />}
                    {stat.trend === 'down' && <ArrowDownRight className="w-4 h-4 text-red-500" />}
                    <span className={`text-sm ${stat.trend === 'up' ? 'text-green-500' : stat.trend === 'down' ? 'text-red-500' : 'text-slate-500'}`}>
                      {stat.change}
                    </span>
                  </div>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center text-white`}>
                  {stat.icon}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Pending Withdrawals */}
        <div className="lg:col-span-2">
          <Card className="bg-slate-900/50 border-white/5">
            <CardHeader className="flex flex-row items-center justify-between pb-4">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-orange-500" />
                <CardTitle className="text-white text-lg">Bekleyen Çekimler</CardTitle>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => navigate('admin-transactions')}
                className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
              >
                Tümünü Gör
                <ArrowUpRight className="w-4 h-4 ml-1" />
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingWithdrawals.map((withdrawal) => (
                  <div 
                    key={withdrawal.id} 
                    className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-orange-500/20 flex items-center justify-center">
                        <DollarSign className="w-5 h-5 text-orange-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">{withdrawal.user}</p>
                        <p className="text-sm text-slate-400">{withdrawal.method} • {withdrawal.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-lg font-bold text-white">₺{withdrawal.amount}</span>
                      <div className="flex gap-2">
                        <Button size="sm" className="bg-green-500/20 text-green-400 hover:bg-green-500/30 border-0">
                          <CheckCircle className="w-4 h-4" />
                        </Button>
                        <Button size="sm" className="bg-red-500/20 text-red-400 hover:bg-red-500/30 border-0">
                          <AlertCircle className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Users */}
        <div>
          <Card className="bg-slate-900/50 border-white/5">
            <CardHeader className="flex flex-row items-center justify-between pb-4">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-500" />
                <CardTitle className="text-white text-lg">Son Kullanıcılar</CardTitle>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => navigate('admin-users')}
                className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
              >
                Tümü
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentUsers.map((user) => (
                  <div 
                    key={user.id} 
                    className="flex items-center justify-between p-3 rounded-xl bg-white/5"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white font-bold text-sm">
                        {user.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <p className="font-medium text-white text-sm">{user.name}</p>
                        <p className="text-xs text-slate-400">{user.email}</p>
                      </div>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      user.status === 'active' 
                        ? 'bg-green-500/20 text-green-400' 
                        : 'bg-yellow-500/20 text-yellow-400'
                    }`}>
                      {user.status === 'active' ? 'Aktif' : 'Bekliyor'}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Popular Tasks */}
      <div className="mt-6">
        <Card className="bg-slate-900/50 border-white/5">
          <CardHeader className="flex flex-row items-center justify-between pb-4">
            <div className="flex items-center gap-2">
              <ListTodo className="w-5 h-5 text-green-500" />
              <CardTitle className="text-white text-lg">Popüler Görevler</CardTitle>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('admin-tasks')}
              className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
            >
              Tümünü Gör
              <ArrowUpRight className="w-4 h-4 ml-1" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/5">
                    <th className="text-left py-3 px-4 text-sm font-medium text-slate-400">Görev</th>
                    <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">Başvuru</th>
                    <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">Tamamlama</th>
                    <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">Oran</th>
                    <th className="text-right py-3 px-4 text-sm font-medium text-slate-400">Ödül</th>
                  </tr>
                </thead>
                <tbody>
                  {recentTasks.map((task) => (
                    <tr key={task.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                      <td className="py-4 px-4 text-white">{task.title}</td>
                      <td className="py-4 px-4 text-center text-slate-300">{task.applications}</td>
                      <td className="py-4 px-4 text-center text-slate-300">{task.completions}</td>
                      <td className="py-4 px-4 text-center">
                        <span className="text-green-400">{Math.round((task.completions / task.applications) * 100)}%</span>
                      </td>
                      <td className="py-4 px-4 text-right text-green-400 font-medium">₺{task.reward}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
