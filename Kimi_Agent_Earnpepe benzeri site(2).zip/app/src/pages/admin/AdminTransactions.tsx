import { AdminLayout } from '../../components/admin/AdminLayout';
import { useState } from 'react';
import { 
  Search, 
  ArrowDownLeft, 
  ArrowUpRight, 
  CheckCircle,
  XCircle,
  DollarSign,
  Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';


interface AdminTransactionsProps {
  navigate: (page: string) => void;
}

const initialTransactions = [
  {
    id: 1,
    user: 'Ahmet Yılmaz',
    userEmail: 'ahmet@email.com',
    type: 'withdraw',
    amount: 500,
    method: 'Papara',
    status: 'pending',
    date: '2025-01-15 14:30',
    accountInfo: '1234567890',
  },
  {
    id: 2,
    user: 'Zeynep Kaya',
    userEmail: 'zeynep@email.com',
    type: 'withdraw',
    amount: 1200,
    method: 'Banka Transferi',
    status: 'pending',
    date: '2025-01-15 13:00',
    accountInfo: 'TR00 1234 5678 9012 3456 7890 12',
  },
  {
    id: 3,
    user: 'Mehmet Demir',
    userEmail: 'mehmet@email.com',
    type: 'income',
    amount: 45,
    method: 'Görev Ödemesi',
    status: 'completed',
    date: '2025-01-15 12:30',
    accountInfo: '-',
  },
  {
    id: 4,
    user: 'Elif Şahin',
    userEmail: 'elif@email.com',
    type: 'withdraw',
    amount: 350,
    method: 'PayPal',
    status: 'completed',
    date: '2025-01-15 11:30',
    accountInfo: 'elif@paypal.com',
  },
  {
    id: 5,
    user: 'Can Özdemir',
    userEmail: 'can@email.com',
    type: 'income',
    amount: 120,
    method: 'Görev Ödemesi',
    status: 'completed',
    date: '2025-01-15 10:15',
    accountInfo: '-',
  },
  {
    id: 6,
    user: 'Ahmet Yılmaz',
    userEmail: 'ahmet@email.com',
    type: 'withdraw',
    amount: 250,
    method: 'Kripto (USDT)',
    status: 'rejected',
    date: '2025-01-14 18:00',
    accountInfo: '0x1234...5678',
  },
];

export default function AdminTransactions({ navigate }: AdminTransactionsProps) {
  const [transactions, setTransactions] = useState(initialTransactions);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [selectedTransaction, setSelectedTransaction] = useState<any>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const filteredTransactions = transactions.filter(tx => {
    const matchesSearch = tx.user.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         tx.userEmail.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || tx.status === statusFilter;
    const matchesType = typeFilter === 'all' || tx.type === typeFilter;
    return matchesSearch && matchesStatus && matchesType;
  });

  const handleApprove = (id: number) => {
    setTransactions(transactions.map(tx => 
      tx.id === id ? { ...tx, status: 'completed' } : tx
    ));
  };

  const handleReject = (id: number) => {
    setTransactions(transactions.map(tx => 
      tx.id === id ? { ...tx, status: 'rejected' } : tx
    ));
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-500/20 text-green-400 border-0">Onaylandı</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-0">Bekliyor</Badge>;
      case 'rejected':
        return <Badge className="bg-red-500/20 text-red-400 border-0">Reddedildi</Badge>;
      default:
        return <Badge className="bg-slate-500/20 text-slate-400 border-0">Bilinmiyor</Badge>;
    }
  };

  const totalPending = transactions
    .filter(tx => tx.status === 'pending' && tx.type === 'withdraw')
    .reduce((sum, tx) => sum + tx.amount, 0);

  const totalWithdrawn = transactions
    .filter(tx => tx.status === 'completed' && tx.type === 'withdraw')
    .reduce((sum, tx) => sum + tx.amount, 0);

  const totalIncome = transactions
    .filter(tx => tx.type === 'income')
    .reduce((sum, tx) => sum + tx.amount, 0);

  return (
    <AdminLayout navigate={navigate} currentPage="admin-transactions">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Bakiye İşlemleri</h1>
        <p className="text-slate-400">Para çekme taleplerini ve işlemleri yönet</p>
      </div>

      {/* Stats */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card className="bg-slate-900/50 border-white/5">
          <CardContent className="p-4">
            <p className="text-sm text-slate-400">Bekleyen Çekim</p>
            <p className="text-2xl font-bold text-yellow-400">₺{totalPending.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-900/50 border-white/5">
          <CardContent className="p-4">
            <p className="text-sm text-slate-400">Toplam Çekilen</p>
            <p className="text-2xl font-bold text-purple-400">₺{totalWithdrawn.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-900/50 border-white/5">
          <CardContent className="p-4">
            <p className="text-sm text-slate-400">Toplam Kazanç</p>
            <p className="text-2xl font-bold text-green-400">₺{totalIncome.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-900/50 border-white/5">
          <CardContent className="p-4">
            <p className="text-sm text-slate-400">Bekleyen Talep</p>
            <p className="text-2xl font-bold text-orange-400">
              {transactions.filter(tx => tx.status === 'pending' && tx.type === 'withdraw').length}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="bg-slate-900/50 border-white/5 mb-6">
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <Input
                type="text"
                placeholder="Kullanıcı ara..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white/5 border-white/10 text-white"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
              >
                <option value="all">Tüm İşlemler</option>
                <option value="withdraw">Para Çekme</option>
                <option value="income">Kazanç</option>
              </select>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-white"
              >
                <option value="all">Tüm Durumlar</option>
                <option value="pending">Bekliyor</option>
                <option value="completed">Onaylandı</option>
                <option value="rejected">Reddedildi</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Transactions Table */}
      <Card className="bg-slate-900/50 border-white/5">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  <th className="text-left py-4 px-6 text-sm font-medium text-slate-400">Kullanıcı</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Tür</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Tutar</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Yöntem</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Durum</th>
                  <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">Tarih</th>
                  <th className="text-right py-4 px-6 text-sm font-medium text-slate-400">İşlemler</th>
                </tr>
              </thead>
              <tbody>
                {filteredTransactions.map((tx) => (
                  <tr key={tx.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white font-bold text-sm">
                          {tx.user.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <p className="font-medium text-white">{tx.user}</p>
                          <p className="text-xs text-slate-400">{tx.userEmail}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-center">
                      {tx.type === 'withdraw' ? (
                        <div className="flex items-center justify-center gap-1 text-red-400">
                          <ArrowUpRight className="w-4 h-4" />
                          <span>Çekim</span>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center gap-1 text-green-400">
                          <ArrowDownLeft className="w-4 h-4" />
                          <span>Kazanç</span>
                        </div>
                      )}
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className={`font-bold ${tx.type === 'withdraw' ? 'text-red-400' : 'text-green-400'}`}>
                        {tx.type === 'withdraw' ? '-' : '+'}₺{tx.amount}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center text-slate-300">{tx.method}</td>
                    <td className="py-4 px-4 text-center">
                      {getStatusBadge(tx.status)}
                    </td>
                    <td className="py-4 px-4 text-center text-slate-400 text-sm">{tx.date}</td>
                    <td className="py-4 px-6 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="text-slate-400 hover:text-white"
                          onClick={() => { setSelectedTransaction(tx); setIsDetailOpen(true); }}
                        >
                          <DollarSign className="w-4 h-4" />
                        </Button>

                        {tx.status === 'pending' && tx.type === 'withdraw' && (
                          <>
                            <Button 
                              size="sm" 
                              className="bg-green-500/20 text-green-400 hover:bg-green-500/30 border-0"
                              onClick={() => handleApprove(tx.id)}
                            >
                              <CheckCircle className="w-4 h-4" />
                            </Button>
                            <Button 
                              size="sm" 
                              className="bg-red-500/20 text-red-400 hover:bg-red-500/30 border-0"
                              onClick={() => handleReject(tx.id)}
                            >
                              <XCircle className="w-4 h-4" />
                            </Button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="bg-slate-900 border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-white">İşlem Detayları</DialogTitle>
          </DialogHeader>
          {selectedTransaction && (
            <div className="space-y-4 mt-4">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white font-bold text-lg">
                  {selectedTransaction.user.split(' ').map((n: string) => n[0]).join('')}
                </div>
                <div>
                  <p className="text-lg font-bold text-white">{selectedTransaction.user}</p>
                  <p className="text-slate-400">{selectedTransaction.userEmail}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-white/5">
                  <p className="text-xs text-slate-400">İşlem Türü</p>
                  <p className={`text-lg font-bold ${selectedTransaction.type === 'withdraw' ? 'text-red-400' : 'text-green-400'}`}>
                    {selectedTransaction.type === 'withdraw' ? 'Para Çekme' : 'Kazanç'}
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-white/5">
                  <p className="text-xs text-slate-400">Tutar</p>
                  <p className="text-lg font-bold text-white">₺{selectedTransaction.amount}</p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-white/5">
                <p className="text-xs text-slate-400 mb-1">Ödeme Yöntemi</p>
                <p className="text-white">{selectedTransaction.method}</p>
              </div>

              <div className="p-4 rounded-xl bg-white/5">
                <p className="text-xs text-slate-400 mb-1">Hesap Bilgisi</p>
                <p className="text-white font-mono text-sm">{selectedTransaction.accountInfo}</p>
              </div>

              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-slate-400" />
                <span className="text-slate-300">{selectedTransaction.date}</span>
              </div>

              <div className="flex items-center gap-2">
                {getStatusBadge(selectedTransaction.status)}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
