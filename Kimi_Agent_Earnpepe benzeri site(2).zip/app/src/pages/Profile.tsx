import { DashboardLayout } from '../components/dashboard/DashboardLayout';
import { useState } from 'react';
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Edit2, 
  Camera,
  Shield,
  Award,
  TrendingUp,
  CheckCircle,
  Lock,
  Bell,
  Smartphone
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';

interface ProfileProps {
  navigate: (page: string) => void;
}

const userStats = {
  level: 12,
  xp: 2450,
  nextLevelXp: 3000,
  memberSince: '2024-08-15',
  totalTasks: 156,
  successRate: 98,
  referralCount: 23,
  referralEarnings: 450,
};

const badges = [
  { id: 1, name: 'Hızlı Başlangıç', description: 'İlk 10 görevi tamamla', icon: '🚀', unlocked: true },
  { id: 2, name: 'Kazanç Ustası', description: '₺1000 kazan', icon: '💰', unlocked: true },
  { id: 3, name: 'Referans Kralı', description: '10 arkadaş davet et', icon: '👑', unlocked: true },
  { id: 4, name: 'Görev Canavarı', description: '100 görev tamamla', icon: '👹', unlocked: true },
  { id: 5, name: 'Mükemmel Puan', description: '50 görevi 5 yıldızla tamamla', icon: '⭐', unlocked: false },
  { id: 6, name: 'Yatırımcı', description: '₺5000 yatırım yap', icon: '📈', unlocked: false },
];

const achievements = [
  { id: 1, title: '7 Gün Üst Üste Görev', date: '2025-01-10', reward: 50 },
  { id: 2, title: 'İlk Para Çekimi', date: '2024-09-20', reward: 0 },
  { id: 3, title: 'İlk Referans', date: '2024-09-05', reward: 10 },
  { id: 4, title: 'Seviye 10\'a Ulaşma', date: '2024-12-15', reward: 100 },
];

export default function Profile({ navigate }: ProfileProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [user, setUser] = useState({
    name: 'Ahmet Yılmaz',
    email: 'ahmet.yilmaz@email.com',
    phone: '+90 555 123 45 67',
    city: 'İstanbul',
    bio: 'Öğrenciyim, boş zamanlarımda görev yaparak para kazanıyorum.',
  });

  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    taskAlerts: true,
    paymentAlerts: true,
    newsletter: false,
  });

  const progressPercent = (userStats.xp / userStats.nextLevelXp) * 100;

  return (
    <DashboardLayout navigate={navigate} currentPage="profile">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Profilim</h1>
        <p className="text-slate-400">Hesap bilgilerin ve istatistiklerin</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left Column - Profile Info */}
        <div className="lg:col-span-1 space-y-6">
          {/* Profile Card */}
          <Card className="bg-slate-900/50 border-white/5">
            <CardContent className="p-6 text-center">
              {/* Avatar */}
              <div className="relative inline-block mb-4">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-3xl text-white font-bold mx-auto">
                  AY
                </div>
                <button className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-slate-800 border-2 border-slate-900 flex items-center justify-center text-slate-400 hover:text-white transition-colors">
                  <Camera className="w-4 h-4" />
                </button>
              </div>

              {/* Name & Level */}
              <h2 className="text-xl font-bold text-white mb-1">{user.name}</h2>
              <div className="flex items-center justify-center gap-2 mb-4">
                <Badge className="bg-gradient-to-r from-yellow-500 to-amber-500 text-white border-0">
                  <Award className="w-3 h-3 mr-1" />
                  Seviye {userStats.level}
                </Badge>
                <Badge className="bg-green-500/20 text-green-400 border-0">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              </div>

              {/* XP Progress */}
              <div className="mb-4">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-slate-400">XP: {userStats.xp}/{userStats.nextLevelXp}</span>
                  <span className="text-green-400">%{Math.round(progressPercent)}</span>
                </div>
                <div className="h-3 rounded-full bg-slate-800 overflow-hidden">
                  <div 
                    className="h-full rounded-full bg-gradient-to-r from-green-500 to-emerald-500 transition-all"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>

              {/* Member Since */}
              <div className="flex items-center justify-center gap-2 text-sm text-slate-400">
                <Calendar className="w-4 h-4" />
                <span>Üyelik: {new Date(userStats.memberSince).toLocaleDateString('tr-TR')}</span>
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card className="bg-slate-900/50 border-white/5">
            <CardHeader>
              <CardTitle className="text-white text-lg">İstatistiklerim</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-3 rounded-xl bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-blue-500" />
                  </div>
                  <span className="text-slate-300">Tamamlanan Görev</span>
                </div>
                <span className="text-lg font-bold text-white">{userStats.totalTasks}</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  </div>
                  <span className="text-slate-300">Başarı Oranı</span>
                </div>
                <span className="text-lg font-bold text-white">%{userStats.successRate}</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                    <User className="w-5 h-5 text-purple-500" />
                  </div>
                  <span className="text-slate-300">Davet Ettiğim</span>
                </div>
                <span className="text-lg font-bold text-white">{userStats.referralCount}</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-yellow-500/20 flex items-center justify-center">
                    <Award className="w-5 h-5 text-yellow-500" />
                  </div>
                  <span className="text-slate-300">Ref. Kazancı</span>
                </div>
                <span className="text-lg font-bold text-green-400">₺{userStats.referralEarnings}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Tabs */}
        <div className="lg:col-span-2">
          <Tabs defaultValue="info" className="space-y-6">
            <TabsList className="bg-slate-900/50 border border-white/5 p-1">
              <TabsTrigger value="info" className="data-[state=active]:bg-green-500/20 data-[state=active]:text-green-400">
                <User className="w-4 h-4 mr-2" />
                Bilgilerim
              </TabsTrigger>
              <TabsTrigger value="badges" className="data-[state=active]:bg-yellow-500/20 data-[state=active]:text-yellow-400">
                <Award className="w-4 h-4 mr-2" />
                Rozetlerim
              </TabsTrigger>
              <TabsTrigger value="security" className="data-[state=active]:bg-blue-500/20 data-[state=active]:text-blue-400">
                <Shield className="w-4 h-4 mr-2" />
                Güvenlik
              </TabsTrigger>
              <TabsTrigger value="notifications" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                <Bell className="w-4 h-4 mr-2" />
                Bildirimler
              </TabsTrigger>
            </TabsList>

            {/* Info Tab */}
            <TabsContent value="info">
              <Card className="bg-slate-900/50 border-white/5">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-white text-lg">Kişisel Bilgiler</CardTitle>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setIsEditing(!isEditing)}
                    className="text-green-400 hover:text-green-300 hover:bg-green-500/10"
                  >
                    <Edit2 className="w-4 h-4 mr-2" />
                    {isEditing ? 'Kaydet' : 'Düzenle'}
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm text-slate-400 mb-2 block">Ad Soyad</label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                        <Input
                          value={user.name}
                          onChange={(e) => setUser({...user, name: e.target.value})}
                          disabled={!isEditing}
                          className="pl-10 bg-white/5 border-white/10 text-white disabled:opacity-50"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-sm text-slate-400 mb-2 block">E-posta</label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                        <Input
                          value={user.email}
                          onChange={(e) => setUser({...user, email: e.target.value})}
                          disabled={!isEditing}
                          className="pl-10 bg-white/5 border-white/10 text-white disabled:opacity-50"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-sm text-slate-400 mb-2 block">Telefon</label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                        <Input
                          value={user.phone}
                          onChange={(e) => setUser({...user, phone: e.target.value})}
                          disabled={!isEditing}
                          className="pl-10 bg-white/5 border-white/10 text-white disabled:opacity-50"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-sm text-slate-400 mb-2 block">Şehir</label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                        <Input
                          value={user.city}
                          onChange={(e) => setUser({...user, city: e.target.value})}
                          disabled={!isEditing}
                          className="pl-10 bg-white/5 border-white/10 text-white disabled:opacity-50"
                        />
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-slate-400 mb-2 block">Hakkımda</label>
                    <textarea
                      value={user.bio}
                      onChange={(e) => setUser({...user, bio: e.target.value})}
                      disabled={!isEditing}
                      rows={3}
                      className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white disabled:opacity-50 resize-none focus:outline-none focus:border-green-500"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Achievements */}
              <Card className="bg-slate-900/50 border-white/5 mt-6">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Son Başarılarım</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {achievements.map((achievement) => (
                      <div 
                        key={achievement.id} 
                        className="flex items-center justify-between p-4 rounded-xl bg-white/5"
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-lg bg-yellow-500/20 flex items-center justify-center">
                            <Award className="w-5 h-5 text-yellow-500" />
                          </div>
                          <div>
                            <p className="font-medium text-white">{achievement.title}</p>
                            <p className="text-sm text-slate-400">{new Date(achievement.date).toLocaleDateString('tr-TR')}</p>
                          </div>
                        </div>
                        {achievement.reward > 0 && (
                          <Badge className="bg-green-500/20 text-green-400 border-0">
                            +₺{achievement.reward}
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Badges Tab */}
            <TabsContent value="badges">
              <Card className="bg-slate-900/50 border-white/5">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Kazandığım Rozetler</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid sm:grid-cols-2 gap-4">
                    {badges.map((badge) => (
                      <div 
                        key={badge.id} 
                        className={`p-4 rounded-xl border transition-all ${
                          badge.unlocked 
                            ? 'bg-white/5 border-white/10' 
                            : 'bg-white/[0.02] border-white/5 opacity-50'
                        }`}
                      >
                        <div className="flex items-start gap-4">
                          <div className={`w-14 h-14 rounded-xl flex items-center justify-center text-2xl ${
                            badge.unlocked 
                              ? 'bg-gradient-to-br from-yellow-500 to-amber-500' 
                              : 'bg-slate-800'
                          }`}>
                            {badge.unlocked ? badge.icon : '🔒'}
                          </div>
                          <div>
                            <h3 className={`font-medium ${badge.unlocked ? 'text-white' : 'text-slate-500'}`}>
                              {badge.name}
                            </h3>
                            <p className="text-sm text-slate-400 mt-1">{badge.description}</p>
                            {badge.unlocked && (
                              <Badge className="mt-2 bg-green-500/20 text-green-400 border-0">
                                <CheckCircle className="w-3 h-3 mr-1" />
                                Kazanıldı
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Security Tab */}
            <TabsContent value="security">
              <Card className="bg-slate-900/50 border-white/5">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Güvenlik Ayarları</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                        <Lock className="w-5 h-5 text-blue-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">Şifre Değiştir</p>
                        <p className="text-sm text-slate-400">Son değiştirme: 30 gün önce</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="border-white/10 text-white hover:bg-white/5">
                      Değiştir
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                        <Smartphone className="w-5 h-5 text-green-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">İki Faktörlü Doğrulama</p>
                        <p className="text-sm text-slate-400">Hesabınızı daha güvenli yapın</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="border-white/10 text-white hover:bg-white/5">
                      Etkinleştir
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                        <Shield className="w-5 h-5 text-purple-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">Oturum Yönetimi</p>
                        <p className="text-sm text-slate-400">Aktif oturumlarınızı görüntüleyin</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="border-white/10 text-white hover:bg-white/5">
                      Yönet
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications">
              <Card className="bg-slate-900/50 border-white/5">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Bildirim Tercihleri</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                        <Mail className="w-5 h-5 text-blue-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">E-posta Bildirimleri</p>
                        <p className="text-sm text-slate-400">Önemli güncellemeleri e-posta al</p>
                      </div>
                    </div>
                    <Switch 
                      checked={notifications.email}
                      onCheckedChange={(checked) => setNotifications({...notifications, email: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                        <Bell className="w-5 h-5 text-green-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">Push Bildirimleri</p>
                        <p className="text-sm text-slate-400">Anlık bildirimleri al</p>
                      </div>
                    </div>
                    <Switch 
                      checked={notifications.push}
                      onCheckedChange={(checked) => setNotifications({...notifications, push: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                        <CheckCircle className="w-5 h-5 text-purple-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">Görev Bildirimleri</p>
                        <p className="text-sm text-slate-400">Yeni görevlerden haberdar ol</p>
                      </div>
                    </div>
                    <Switch 
                      checked={notifications.taskAlerts}
                      onCheckedChange={(checked) => setNotifications({...notifications, taskAlerts: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-yellow-500/20 flex items-center justify-center">
                        <TrendingUp className="w-5 h-5 text-yellow-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">Ödeme Bildirimleri</p>
                        <p className="text-sm text-slate-400">Para çekme ve yatırma bildirimleri</p>
                      </div>
                    </div>
                    <Switch 
                      checked={notifications.paymentAlerts}
                      onCheckedChange={(checked) => setNotifications({...notifications, paymentAlerts: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-pink-500/20 flex items-center justify-center">
                        <Mail className="w-5 h-5 text-pink-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">Bülten</p>
                        <p className="text-sm text-slate-400">Haftalık kampanya ve fırsatlar</p>
                      </div>
                    </div>
                    <Switch 
                      checked={notifications.newsletter}
                      onCheckedChange={(checked) => setNotifications({...notifications, newsletter: checked})}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </DashboardLayout>
  );
}
