import { DashboardLayout } from '../components/dashboard/DashboardLayout';
import { useState } from 'react';
import { 
  Search, 
  Filter, 
  Clock, 
  DollarSign, 
  Star, 
  TrendingUp,
  CheckCircle,
  Play,
  ClipboardList,
  Smartphone,
  Share2,
  Gamepad2,
  Mail
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

interface TasksProps {
  navigate: (page: string) => void;
}

const categories = [
  { id: 'all', name: 'Tümü', icon: <ClipboardList className="w-4 h-4" /> },
  { id: 'survey', name: 'Anket', icon: <ClipboardList className="w-4 h-4" /> },
  { id: 'app', name: 'Uygulama', icon: <Smartphone className="w-4 h-4" /> },
  { id: 'video', name: 'Video', icon: <Play className="w-4 h-4" /> },
  { id: 'social', name: 'Sosyal', icon: <Share2 className="w-4 h-4" /> },
  { id: 'game', name: 'Oyun', icon: <Gamepad2 className="w-4 h-4" /> },
  { id: 'register', name: 'Kayıt', icon: <Mail className="w-4 h-4" /> },
];

const tasks = [
  {
    id: 1,
    title: 'TikTok Uygulamasını İndir ve 3 Gün Kullan',
    category: 'app',
    reward: 45,
    duration: '3 gün',
    difficulty: 'Kolay',
    rating: 4.8,
    completions: 2340,
    description: 'TikTok uygulamasını indir, hesap oluştur ve 3 gün boyunca günlük en az 15 dakika kullan.',
    requirements: ['Android 8.0+ veya iOS 13+', 'Yeni hesap oluşturma'],
    icon: '📱',
    color: 'from-pink-500 to-rose-500',
    featured: true,
  },
  {
    id: 2,
    title: 'Market Araştırması Anketi',
    category: 'survey',
    reward: 25,
    duration: '10 dk',
    difficulty: 'Kolay',
    rating: 4.6,
    completions: 5670,
    description: 'Alışveriş alışkanlıklarınız hakkında kısa bir anket doldurun.',
    requirements: ['18 yaş üzeri', 'Türkiye\'de ikamet'],
    icon: '📊',
    color: 'from-blue-500 to-cyan-500',
    featured: false,
  },
  {
    id: 3,
    title: 'YouTube Videosu İzle ve Beğen',
    category: 'video',
    reward: 8,
    duration: '5 dk',
    difficulty: 'Çok Kolay',
    rating: 4.9,
    completions: 8900,
    description: 'Belirtilen videoyu tamamen izleyin ve beğen butonuna tıklayın.',
    requirements: ['YouTube hesabı', 'Gerçek kullanıcı'],
    icon: '▶️',
    color: 'from-red-500 to-orange-500',
    featured: false,
  },
  {
    id: 4,
    title: 'Instagram Hesabını Takip Et',
    category: 'social',
    reward: 5,
    duration: '1 dk',
    difficulty: 'Çok Kolay',
    rating: 4.7,
    completions: 12300,
    description: 'Belirtilen Instagram hesabını takip edin ve 7 gün takipte kalın.',
    requirements: ['Instagram hesabı', '7 gün takipte kalma'],
    icon: '📷',
    color: 'from-purple-500 to-pink-500',
    featured: false,
  },
  {
    id: 5,
    title: 'Mobil Oyun - Seviye 10\'a Ulaş',
    category: 'game',
    reward: 120,
    duration: '2-3 gün',
    difficulty: 'Orta',
    rating: 4.5,
    completions: 890,
    description: 'Oyunu indir ve seviye 10\'a ulaş. Ödül seviye atladıkça artar.',
    requirements: ['Android veya iOS', 'Yeni oyuncu'],
    icon: '🎮',
    color: 'from-green-500 to-emerald-500',
    featured: true,
  },
  {
    id: 6,
    title: 'E-posta Bültenine Kaydol',
    category: 'register',
    reward: 12,
    duration: '2 dk',
    difficulty: 'Çok Kolay',
    rating: 4.8,
    completions: 4560,
    description: 'Web sitesine kaydol ve e-posta bültenine abone ol.',
    requirements: ['Geçerli e-posta adresi', 'E-posta doğrulama'],
    icon: '✉️',
    color: 'from-indigo-500 to-violet-500',
    featured: false,
  },
  {
    id: 7,
    title: 'Ürün İnceleme Yaz',
    category: 'survey',
    reward: 35,
    duration: '15 dk',
    difficulty: 'Orta',
    rating: 4.4,
    completions: 1230,
    description: 'Kullandığınız bir ürün hakkında 100+ kelime inceleme yazın.',
    requirements: ['Ürün deneyimi', 'Özgün içerik'],
    icon: '✍️',
    color: 'from-yellow-500 to-amber-500',
    featured: false,
  },
  {
    id: 8,
    title: 'Twitter\'da Retweet Yap',
    category: 'social',
    reward: 6,
    duration: '1 dk',
    difficulty: 'Çok Kolay',
    rating: 4.6,
    completions: 7890,
    description: 'Belirtilen tweeti retweetleyin ve 24 saat silmeyin.',
    requirements: ['Twitter hesabı', 'Aktif hesap'],
    icon: '🐦',
    color: 'from-sky-500 to-blue-500',
    featured: false,
  },
];

export default function Tasks({ navigate }: TasksProps) {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTasks = tasks.filter(task => {
    const matchesCategory = activeCategory === 'all' || task.category === activeCategory;
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <DashboardLayout navigate={navigate} currentPage="tasks">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Görevler</h1>
        <p className="text-slate-400">Sana uygun görevleri seç ve para kazanmaya başla!</p>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
          <Input
            type="text"
            placeholder="Görev ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-slate-900/50 border-white/10 text-white placeholder:text-slate-500 focus:border-green-500"
          />
        </div>
        <Button variant="outline" className="border-white/10 text-slate-300 hover:bg-white/5">
          <Filter className="w-4 h-4 mr-2" />
          Filtrele
        </Button>
      </div>

      {/* Categories */}
      <div className="flex gap-2 overflow-x-auto pb-4 mb-6 scrollbar-hide">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl whitespace-nowrap transition-all ${
              activeCategory === cat.id
                ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                : 'bg-slate-900/50 text-slate-400 border border-white/5 hover:border-white/10'
            }`}
          >
            {cat.icon}
            <span className="text-sm font-medium">{cat.name}</span>
          </button>
        ))}
      </div>

      {/* Tasks Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredTasks.map((task) => (
          <Dialog key={task.id}>
            <DialogTrigger asChild>
              <Card 
                className="bg-slate-900/50 border-white/5 hover:border-green-500/30 transition-all cursor-pointer group overflow-hidden"
              >
                <CardContent className="p-5">
                  {/* Featured Badge */}
                  {task.featured && (
                    <div className="absolute top-3 right-3">
                      <Badge className="bg-gradient-to-r from-yellow-500 to-amber-500 text-white border-0 text-xs">
                        <TrendingUp className="w-3 h-3 mr-1" />
                        Popüler
                      </Badge>
                    </div>
                  )}

                  {/* Icon & Category */}
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${task.color} flex items-center justify-center text-2xl shadow-lg group-hover:scale-110 transition-transform`}>
                      {task.icon}
                    </div>
                    <Badge variant="secondary" className="bg-white/5 text-slate-400 border-0">
                      {categories.find(c => c.id === task.category)?.name}
                    </Badge>
                  </div>

                  {/* Title */}
                  <h3 className="text-lg font-bold text-white mb-2 line-clamp-2 group-hover:text-green-400 transition-colors">
                    {task.title}
                  </h3>

                  {/* Stats */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    <div className="flex items-center gap-1 text-xs text-slate-400">
                      <Clock className="w-3 h-3" />
                      {task.duration}
                    </div>
                    <div className="flex items-center gap-1 text-xs text-slate-400">
                      <Star className="w-3 h-3 text-yellow-500" />
                      {task.rating}
                    </div>
                    <div className="flex items-center gap-1 text-xs text-slate-400">
                      <CheckCircle className="w-3 h-3 text-green-500" />
                      {task.completions.toLocaleString()}
                    </div>
                  </div>

                  {/* Difficulty */}
                  <div className="mb-4">
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      task.difficulty === 'Çok Kolay' ? 'bg-green-500/20 text-green-400' :
                      task.difficulty === 'Kolay' ? 'bg-blue-500/20 text-blue-400' :
                      'bg-yellow-500/20 text-yellow-400'
                    }`}>
                      {task.difficulty}
                    </span>
                  </div>

                  {/* Reward */}
                  <div className="flex items-center justify-between pt-4 border-t border-white/5">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-green-500/10 flex items-center justify-center">
                        <DollarSign className="w-4 h-4 text-green-500" />
                      </div>
                      <span className="text-lg font-bold text-green-400">₺{task.reward}</span>
                    </div>
                    <Button size="sm" className="gradient-primary hover:opacity-90 text-white border-0">
                      Başvur
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </DialogTrigger>
            
            <DialogContent className="bg-slate-900 border-white/10 text-white max-w-lg">
              <DialogHeader>
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${task.color} flex items-center justify-center text-3xl mb-4`}>
                  {task.icon}
                </div>
                <DialogTitle className="text-xl text-white">{task.title}</DialogTitle>
                <DialogDescription className="text-slate-400">
                  {task.description}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 mt-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-3 rounded-xl bg-white/5 text-center">
                    <Clock className="w-5 h-5 text-slate-400 mx-auto mb-1" />
                    <p className="text-xs text-slate-400">Süre</p>
                    <p className="font-medium text-white">{task.duration}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 text-center">
                    <Star className="w-5 h-5 text-yellow-500 mx-auto mb-1" />
                    <p className="text-xs text-slate-400">Puan</p>
                    <p className="font-medium text-white">{task.rating}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 text-center">
                    <DollarSign className="w-5 h-5 text-green-500 mx-auto mb-1" />
                    <p className="text-xs text-slate-400">Ödül</p>
                    <p className="font-medium text-green-400">₺{task.reward}</p>
                  </div>
                </div>

                <div>
                  <p className="text-sm font-medium text-white mb-2">Gereksinimler:</p>
                  <ul className="space-y-2">
                    {task.requirements.map((req, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-sm text-slate-400">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        {req}
                      </li>
                    ))}
                  </ul>
                </div>

                <Button className="w-full gradient-primary hover:opacity-90 text-white border-0 py-6">
                  Göreve Başla
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        ))}
      </div>

      {/* Empty State */}
      {filteredTasks.length === 0 && (
        <div className="text-center py-16">
          <div className="w-20 h-20 rounded-full bg-slate-800 flex items-center justify-center mx-auto mb-4">
            <Search className="w-10 h-10 text-slate-500" />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">Görev bulunamadı</h3>
          <p className="text-slate-400">Farklı bir arama terimi veya kategori deneyin.</p>
        </div>
      )}
    </DashboardLayout>
  );
}
