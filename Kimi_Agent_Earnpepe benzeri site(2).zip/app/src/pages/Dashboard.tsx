import { DashboardLayout } from '../components/dashboard/DashboardLayout';
import { 
  Wallet, 
  TrendingUp, 
  CheckCircle, 
  Clock,
  ArrowUpRight,
  Calendar,
  Target
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface DashboardProps {
  navigate: (page: string) => void;
}

const stats = [
  {
    title: 'Toplam Bakiye',
    value: '₺1,245.50',
    change: '+₺125 bugün',
    icon: <Wallet className="w-5 h-5" />,
    trend: 'up',
    color: 'from-green-500 to-emerald-500',
  },
  {
    title: 'Bu Ay Kazanç',
    value: '₺3,450.00',
    change: '+12% geçen aya göre',
    icon: <TrendingUp className="w-5 h-5" />,
    trend: 'up',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    title: 'Tamamlanan Görev',
    value: '156',
    change: '8 görev bekliyor',
    icon: <CheckCircle className="w-5 h-5" />,
    trend: 'neutral',
    color: 'from-purple-500 to-pink-500',
  },
  {
    title: 'Bekleyen Onay',
    value: '3',
    change: 'Ort. onay süresi: 5 dk',
    icon: <Clock className="w-5 h-5" />,
    trend: 'neutral',
    color: 'from-orange-500 to-red-500',
  },
];

const recentTasks = [
  { id: 1, title: 'TikTok Uygulaması İndir', reward: 45, status: 'completed', time: '2 saat önce', icon: '📱' },
  { id: 2, title: 'Market Araştırması Anketi', reward: 25, status: 'pending', time: 'Bekliyor', icon: '📊' },
  { id: 3, title: 'YouTube Videosu İzle', reward: 8, status: 'completed', time: '5 saat önce', icon: '▶️' },
  { id: 4, title: 'Instagram Takip Et', reward: 5, status: 'completed', time: '1 gün önce', icon: '📷' },
];

const dailyTasks = [
  { id: 1, title: 'Günlük Giriş Bonusu', reward: 5, completed: true, icon: '🎁' },
  { id: 2, title: '3 Görev Tamamla', reward: 15, completed: true, icon: '✅' },
  { id: 3, title: 'Arkadaş Davet Et', reward: 10, completed: false, icon: '👥' },
  { id: 4, title: '₺100 Kazan', reward: 20, completed: false, icon: '💰' },
];

export default function Dashboard({ navigate }: DashboardProps) {
  return (
    <DashboardLayout navigate={navigate} currentPage="dashboard">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Dashboard</h1>
        <p className="text-slate-400">Hoş geldin! İşte bugünkü özetin.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <Card key={index} className="bg-slate-900/50 border-white/5 hover:border-green-500/30 transition-all">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-slate-400 mb-1">{stat.title}</p>
                  <p className="text-2xl font-bold text-white">{stat.value}</p>
                  <div className="flex items-center gap-1 mt-2">
                    <span className={`text-sm ${stat.trend === 'up' ? 'text-green-500' : 'text-slate-500'}`}>
                      {stat.change}
                    </span>
                  </div>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center text-white`}>
                  {stat.icon}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent Tasks */}
        <div className="lg:col-span-2">
          <Card className="bg-slate-900/50 border-white/5">
            <CardHeader className="flex flex-row items-center justify-between pb-4">
              <CardTitle className="text-white text-lg">Son Görevlerim</CardTitle>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => navigate('tasks')}
                className="text-green-400 hover:text-green-300 hover:bg-green-500/10"
              >
                Tümünü Gör
                <ArrowUpRight className="w-4 h-4 ml-1" />
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentTasks.map((task) => (
                  <div 
                    key={task.id} 
                    className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center text-2xl">
                        {task.icon}
                      </div>
                      <div>
                        <p className="font-medium text-white">{task.title}</p>
                        <p className="text-sm text-slate-400">{task.time}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-lg font-bold text-green-400">+₺{task.reward}</span>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        task.status === 'completed' 
                          ? 'bg-green-500/20 text-green-400' 
                          : 'bg-yellow-500/20 text-yellow-400'
                      }`}>
                        {task.status === 'completed' ? 'Onaylandı' : 'Bekliyor'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Daily Tasks */}
          <Card className="bg-slate-900/50 border-white/5">
            <CardHeader className="pb-4">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-green-500" />
                <CardTitle className="text-white text-lg">Günlük Görevler</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {dailyTasks.map((task) => (
                  <div 
                    key={task.id} 
                    className={`flex items-center justify-between p-3 rounded-xl ${
                      task.completed ? 'bg-green-500/10' : 'bg-white/5'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-xl">{task.icon}</span>
                      <div>
                        <p className={`text-sm font-medium ${task.completed ? 'text-slate-400 line-through' : 'text-white'}`}>
                          {task.title}
                        </p>
                        <p className="text-xs text-green-400">+₺{task.reward}</p>
                      </div>
                    </div>
                    {task.completed && <CheckCircle className="w-5 h-5 text-green-500" />}
                  </div>
                ))}
              </div>
              <div className="mt-4 p-3 rounded-xl bg-green-500/10 border border-green-500/20">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-400">Günlük Hedef</span>
                  <span className="text-sm font-bold text-green-400">50/100₺</span>
                </div>
                <div className="mt-2 h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div className="h-full w-1/2 rounded-full bg-gradient-to-r from-green-500 to-emerald-500" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="bg-slate-900/50 border-white/5">
            <CardHeader className="pb-4">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-green-500" />
                <CardTitle className="text-white text-lg">Hızlı İşlemler</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                onClick={() => navigate('tasks')}
                className="w-full gradient-primary hover:opacity-90 text-white border-0"
              >
                Yeni Görev Bul
              </Button>
              <Button 
                variant="outline" 
                onClick={() => navigate('wallet')}
                className="w-full border-white/20 text-white hover:bg-white/10"
              >
                Para Çek
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
