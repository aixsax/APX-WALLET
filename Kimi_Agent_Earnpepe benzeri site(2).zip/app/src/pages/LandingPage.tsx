import { Navbar } from '../sections/Navbar';
import { Hero } from '../sections/Hero';
import { Stats } from '../sections/Stats';
import { HowItWorks } from '../sections/HowItWorks';
import { TaskCategories } from '../sections/TaskCategories';
import { PopularTasks } from '../sections/PopularTasks';
import { Features } from '../sections/Features';
import { Testimonials } from '../sections/Testimonials';
import { FAQ } from '../sections/FAQ';
import { CTA } from '../sections/CTA';
import { Footer } from '../sections/Footer';

interface LandingPageProps {
  navigate: (page: string) => void;
}

function LandingPage({ navigate }: LandingPageProps) {
  return (
    <>
      <Navbar navigate={navigate} />
      <main>
        <Hero navigate={navigate} />
        <Stats />
        <HowItWorks />
        <TaskCategories />
        <PopularTasks />
        <Features />
        <Testimonials />
        <FAQ />
        <CTA navigate={navigate} />
      </main>
      <Footer />
    </>
  );
}

export default LandingPage;
