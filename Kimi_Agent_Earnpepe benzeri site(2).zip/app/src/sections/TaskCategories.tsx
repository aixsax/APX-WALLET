import { useEffect, useRef, useState } from 'react';
import { 
  ClipboardList, 
  Smartphone, 
  Play, 
  Share2, 
  Gamepad2, 
  Mail,
  ArrowRight
} from 'lucide-react';

const categories = [
  {
    icon: <ClipboardList className="w-8 h-8" />,
    title: 'Anketler',
    description: 'Fikirlerini paylaş, anketleri doldurarak para kazan. Her anket 5-50₺ arası ödeme yapar.',
    taskCount: '1,250+',
    color: 'from-blue-500 to-cyan-500',
    bgColor: 'bg-blue-500/10',
  },
  {
    icon: <Smartphone className="w-8 h-8" />,
    title: 'Uygulama İndirme',
    description: 'Mobil uygulamaları indir, dene ve yorum yap. Her indirme 10-30₺ kazandırır.',
    taskCount: '850+',
    color: 'from-purple-500 to-pink-500',
    bgColor: 'bg-purple-500/10',
  },
  {
    icon: <Play className="w-8 h-8" />,
    title: 'Video İzleme',
    description: 'Kısa videolar izle ve reklamlara tıkla. Her video başına 2-10₺ kazan.',
    taskCount: '2,100+',
    color: 'from-orange-500 to-red-500',
    bgColor: 'bg-orange-500/10',
  },
  {
    icon: <Share2 className="w-8 h-8" />,
    title: 'Sosyal Medya',
    description: 'Gönderileri beğen, paylaş ve yorum yap. Her etkileşim 3-15₺ değerinde.',
    taskCount: '980+',
    color: 'from-green-500 to-emerald-500',
    bgColor: 'bg-green-500/10',
  },
  {
    icon: <Gamepad2 className="w-8 h-8" />,
    title: 'Oyun Oyna',
    description: 'Mobil oyunları indir ve belirli seviyelere ulaş. Her oyun 20-100₺ ödeme yapar.',
    taskCount: '420+',
    color: 'from-yellow-500 to-amber-500',
    bgColor: 'bg-yellow-500/10',
  },
  {
    icon: <Mail className="w-8 h-8" />,
    title: 'Kayıt Olma',
    description: 'Web sitelerine üye ol ve e-posta doğrula. Her kayıt 5-25₺ arası kazandırır.',
    taskCount: '670+',
    color: 'from-indigo-500 to-violet-500',
    bgColor: 'bg-indigo-500/10',
  },
];

export function TaskCategories() {
  const [visibleCards, setVisibleCards] = useState<number[]>([]);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          categories.forEach((_, index) => {
            setTimeout(() => {
              setVisibleCards((prev) => [...prev, index]);
            }, index * 100);
          });
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="tasks" ref={sectionRef} className="relative py-20 lg:py-32 bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16 lg:mb-20">
          <span className="inline-block px-4 py-2 rounded-full bg-green-500/10 text-green-400 text-sm font-medium mb-4">
            Görev Kategorileri
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Sana Uygun <span className="text-green-400">Görevleri Bul</span>
          </h2>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            Farklı kategorilerde binlerce görev seni bekliyor. İlgi alanlarına göre görev seç ve kazanmaya başla!
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category, index) => (
            <div
              key={index}
              className={`group relative p-6 lg:p-8 rounded-3xl bg-slate-900/50 border border-white/5 hover:border-green-500/30 transition-all duration-500 cursor-pointer overflow-hidden ${
                visibleCards.includes(index)
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-12'
              }`}
            >
              {/* Hover Gradient */}
              <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-5 transition-opacity duration-500`} />
              
              {/* Content */}
              <div className="relative z-10">
                {/* Icon & Task Count */}
                <div className="flex items-start justify-between mb-6">
                  <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl ${category.bgColor} text-white bg-gradient-to-br ${category.color}`}>
                    {category.icon}
                  </div>
                  <span className="px-3 py-1 rounded-full bg-white/5 text-slate-400 text-sm">
                    {category.taskCount} görev
                  </span>
                </div>

                {/* Title & Description */}
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-green-400 transition-colors">
                  {category.title}
                </h3>
                <p className="text-slate-400 leading-relaxed mb-6">
                  {category.description}
                </p>

                {/* CTA */}
                <div className="flex items-center text-green-400 font-medium group-hover:gap-3 transition-all">
                  <span>Görevleri Gör</span>
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
