import { 
  Wallet, 
  Mail, 
  Phone, 
  MapPin, 
  Facebook, 
  Twitter, 
  Instagram, 
  Youtube,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const footerLinks = {
  platform: [
    { name: 'Nasıl Çalışır?', href: '#how-it-works' },
    { name: 'Görevler', href: '#tasks' },
    { name: 'Ödeme Yöntemleri', href: '#' },
    { name: 'SSS', href: '#faq' },
  ],
  company: [
    { name: 'Hakkımızda', href: '#' },
    { name: 'Blog', href: '#' },
    { name: 'Kariyer', href: '#' },
    { name: 'Basın', href: '#' },
  ],
  legal: [
    { name: 'Kullanım Koşulları', href: '#' },
    { name: 'Gizlilik Politikası', href: '#' },
    { name: 'Çerez Politikası', href: '#' },
    { name: 'GDPR', href: '#' },
  ],
  support: [
    { name: 'Yardım Merkezi', href: '#' },
    { name: 'İletişim', href: '#' },
    { name: 'Destek Talebi', href: '#' },
    { name: 'Sık Sorulan Sorular', href: '#faq' },
  ],
};

const socialLinks = [
  { icon: <Facebook className="w-5 h-5" />, href: '#', label: 'Facebook' },
  { icon: <Twitter className="w-5 h-5" />, href: '#', label: 'Twitter' },
  { icon: <Instagram className="w-5 h-5" />, href: '#', label: 'Instagram' },
  { icon: <Youtube className="w-5 h-5" />, href: '#', label: 'Youtube' },
];

export function Footer() {
  return (
    <footer className="relative bg-slate-950 border-t border-white/5">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 lg:gap-12">
          {/* Brand Column */}
          <div className="col-span-2 md:col-span-3 lg:col-span-2">
            {/* Logo */}
            <a href="#hero" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center">
                <Wallet className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
                GörevYap
              </span>
            </a>

            <p className="text-slate-400 mb-6 max-w-sm">
              Türkiye'nin en güvenilir mikro görev platformu. Görev yap, para kazan, hayalini yaşa!
            </p>

            {/* Contact Info */}
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-3 text-slate-400">
                <Mail className="w-4 h-4 text-green-500" />
                <span className="text-sm">destek@gorevyap.com</span>
              </div>
              <div className="flex items-center gap-3 text-slate-400">
                <Phone className="w-4 h-4 text-green-500" />
                <span className="text-sm">0850 123 45 67</span>
              </div>
              <div className="flex items-center gap-3 text-slate-400">
                <MapPin className="w-4 h-4 text-green-500" />
                <span className="text-sm">İstanbul, Türkiye</span>
              </div>
            </div>

            {/* Social Links */}
            <div className="flex gap-3">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-slate-400 hover:bg-green-500/20 hover:text-green-400 transition-all"
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Links Columns */}
          <div>
            <h4 className="text-white font-semibold mb-4">Platform</h4>
            <ul className="space-y-3">
              {footerLinks.platform.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href} 
                    className="text-slate-400 hover:text-green-400 transition-colors text-sm"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Şirket</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href} 
                    className="text-slate-400 hover:text-green-400 transition-colors text-sm"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Yasal</h4>
            <ul className="space-y-3">
              {footerLinks.legal.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href} 
                    className="text-slate-400 hover:text-green-400 transition-colors text-sm"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Destek</h4>
            <ul className="space-y-3">
              {footerLinks.support.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href} 
                    className="text-slate-400 hover:text-green-400 transition-colors text-sm"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Newsletter */}
        <div className="mt-12 pt-12 border-t border-white/5">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            <div>
              <h4 className="text-white font-semibold mb-2">Bültenimize Abone Ol</h4>
              <p className="text-slate-400 text-sm">Yeni görevler ve kampanyalardan haberdar ol!</p>
            </div>
            <div className="flex gap-3 max-w-md w-full lg:w-auto">
              <Input 
                type="email" 
                placeholder="E-posta adresiniz" 
                className="bg-white/5 border-white/10 text-white placeholder:text-slate-500 focus:border-green-500"
              />
              <Button className="gradient-primary hover:opacity-90 text-white border-0 px-6">
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <p className="text-slate-500 text-sm">
              © 2025 GörevYap. Tüm hakları saklıdır.
            </p>
            <div className="flex items-center gap-6">
              <span className="text-slate-500 text-sm">Ödeme Yöntemleri:</span>
              <div className="flex items-center gap-3">
                <span className="px-3 py-1 rounded-lg bg-white/5 text-slate-400 text-xs">Papara</span>
                <span className="px-3 py-1 rounded-lg bg-white/5 text-slate-400 text-xs">PayPal</span>
                <span className="px-3 py-1 rounded-lg bg-white/5 text-slate-400 text-xs">Banka</span>
                <span className="px-3 py-1 rounded-lg bg-white/5 text-slate-400 text-xs">Kripto</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
