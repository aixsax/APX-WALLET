import { useEffect, useRef, useState } from 'react';
import { UserPlus, ListTodo, CheckCircle, Wallet } from 'lucide-react';

const steps = [
  {
    icon: <UserPlus className="w-8 h-8" />,
    number: '01',
    title: 'Ücretsiz Kaydol',
    description: '30 saniyede ücretsiz hesap oluştur. E-posta adresinle hemen başla, kimlik doğrulaması bekleme.',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    icon: <ListTodo className="w-8 h-8" />,
    number: '02',
    title: 'Görev Seç',
    description: 'Anketler, uygulamalar, videolar ve daha fazlası arasından sana uygun görevleri seç ve tamamla.',
    color: 'from-purple-500 to-pink-500',
  },
  {
    icon: <CheckCircle className="w-8 h-8" />,
    number: '03',
    title: 'Onaylanmasını Bekle',
    description: 'Görevlerin otomatik sistem tarafından hızlıca kontrol edilir ve onaylanır. Genellikle birkaç dakika.',
    color: 'from-orange-500 to-red-500',
  },
  {
    icon: <Wallet className="w-8 h-8" />,
    number: '04',
    title: 'Paranı Çek',
    description: 'Kazandığın parayı Papara, PayPal, banka transferi veya kripto para ile anında çek.',
    color: 'from-green-500 to-emerald-500',
  },
];

export function HowItWorks() {
  const [visibleSteps, setVisibleSteps] = useState<number[]>([]);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          steps.forEach((_, index) => {
            setTimeout(() => {
              setVisibleSteps((prev) => [...prev, index]);
            }, index * 200);
          });
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="how-it-works" ref={sectionRef} className="relative py-20 lg:py-32 bg-slate-950">
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-green-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16 lg:mb-20">
          <span className="inline-block px-4 py-2 rounded-full bg-green-500/10 text-green-400 text-sm font-medium mb-4">
            Nasıl Çalışır?
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            4 Adımda <span className="text-green-400">Para Kazan</span>
          </h2>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            GörevYap ile para kazanmak çok kolay! Sadece 4 basit adımda hemen kazanmaya başlayabilirsin.
          </p>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {steps.map((step, index) => (
            <div
              key={index}
              className={`relative group transition-all duration-700 ${
                visibleSteps.includes(index)
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-12'
              }`}
            >
              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-16 left-full w-full h-0.5 bg-gradient-to-r from-green-500/30 to-transparent z-0" />
              )}

              {/* Card */}
              <div className="relative z-10 h-full p-6 lg:p-8 rounded-3xl bg-slate-900/50 border border-white/5 hover:border-green-500/30 transition-all duration-300 hover:shadow-xl hover:shadow-green-500/10 group-hover:-translate-y-2">
                {/* Step Number */}
                <div className="absolute -top-4 -right-4 w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-white font-bold text-lg shadow-lg shadow-green-500/30">
                  {step.number}
                </div>

                {/* Icon */}
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br ${step.color} mb-6 text-white shadow-lg`}>
                  {step.icon}
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-white mb-3">
                  {step.title}
                </h3>
                <p className="text-slate-400 leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
