import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, DollarSign, TrendingUp, Star, ArrowRight } from 'lucide-react';

const tasks = [
  {
    id: 1,
    title: 'TikTok Uygulamasını İndir ve 3 Gün Kullan',
    category: 'Uygulama',
    reward: 45,
    duration: '3 gün',
    difficulty: 'Kolay',
    rating: 4.8,
    completions: 2340,
    icon: '📱',
    color: 'from-pink-500 to-rose-500',
    featured: true,
  },
  {
    id: 2,
    title: 'Market Araştırması Anketi',
    category: 'Anket',
    reward: 25,
    duration: '10 dk',
    difficulty: 'Kolay',
    rating: 4.6,
    completions: 5670,
    icon: '📊',
    color: 'from-blue-500 to-cyan-500',
    featured: false,
  },
  {
    id: 3,
    title: 'YouTube Videosu İzle ve Beğen',
    category: 'Video',
    reward: 8,
    duration: '5 dk',
    difficulty: 'Çok Kolay',
    rating: 4.9,
    completions: 8900,
    icon: '▶️',
    color: 'from-red-500 to-orange-500',
    featured: false,
  },
  {
    id: 4,
    title: 'Instagram Hesabını Takip Et',
    category: 'Sosyal Medya',
    reward: 5,
    duration: '1 dk',
    difficulty: 'Çok Kolay',
    rating: 4.7,
    completions: 12300,
    icon: '📷',
    color: 'from-purple-500 to-pink-500',
    featured: false,
  },
  {
    id: 5,
    title: 'Mobil Oyun - Seviye 10\'a Ulaş',
    category: 'Oyun',
    reward: 120,
    duration: '2-3 gün',
    difficulty: 'Orta',
    rating: 4.5,
    completions: 890,
    icon: '🎮',
    color: 'from-green-500 to-emerald-500',
    featured: true,
  },
  {
    id: 6,
    title: 'E-posta Bültenine Kaydol',
    category: 'Kayıt',
    reward: 12,
    duration: '2 dk',
    difficulty: 'Çok Kolay',
    rating: 4.8,
    completions: 4560,
    icon: '✉️',
    color: 'from-indigo-500 to-violet-500',
    featured: false,
  },
];

export function PopularTasks() {
  const [visibleTasks, setVisibleTasks] = useState<number[]>([]);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          tasks.forEach((_, index) => {
            setTimeout(() => {
              setVisibleTasks((prev) => [...prev, index]);
            }, index * 100);
          });
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-20 lg:py-32 bg-slate-950">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-0 w-96 h-96 bg-green-500/5 rounded-full blur-3xl -translate-y-1/2" />
        <div className="absolute top-1/2 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl -translate-y-1/2" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-12 lg:mb-16">
          <div>
            <span className="inline-block px-4 py-2 rounded-full bg-green-500/10 text-green-400 text-sm font-medium mb-4">
              Popüler Görevler
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
              Bugün <span className="text-green-400">Kazanmaya Başla</span>
            </h2>
            <p className="text-lg text-slate-400 max-w-xl">
              En çok tercih edilen ve yüksek kazançlı görevler. Hemen başvur, hızla onaylan!
            </p>
          </div>
          <Button 
            variant="outline" 
            className="mt-6 lg:mt-0 border-white/20 text-white hover:bg-white/10 w-fit"
          >
            Tüm Görevleri Gör
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>

        {/* Tasks Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {tasks.map((task, index) => (
            <div
              key={task.id}
              className={`group relative rounded-3xl overflow-hidden transition-all duration-500 ${
                visibleTasks.includes(index)
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-12'
              }`}
            >
              {/* Card */}
              <div className="relative h-full p-6 bg-slate-900/80 border border-white/5 hover:border-green-500/30 transition-all duration-300 hover:shadow-xl hover:shadow-green-500/10">
                {/* Featured Badge */}
                {task.featured && (
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-gradient-to-r from-yellow-500 to-amber-500 text-white border-0">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      Popüler
                    </Badge>
                  </div>
                )}

                {/* Icon & Category */}
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${task.color} flex items-center justify-center text-2xl shadow-lg`}>
                    {task.icon}
                  </div>
                  <Badge variant="secondary" className="bg-white/5 text-slate-400 border-0">
                    {task.category}
                  </Badge>
                </div>

                {/* Title */}
                <h3 className="text-lg font-bold text-white mb-3 line-clamp-2 group-hover:text-green-400 transition-colors">
                  {task.title}
                </h3>

                {/* Stats */}
                <div className="flex flex-wrap gap-3 mb-4">
                  <div className="flex items-center gap-1 text-sm text-slate-400">
                    <Clock className="w-4 h-4" />
                    {task.duration}
                  </div>
                  <div className="flex items-center gap-1 text-sm text-slate-400">
                    <Star className="w-4 h-4 text-yellow-500" />
                    {task.rating}
                  </div>
                  <div className="flex items-center gap-1 text-sm text-slate-400">
                    <span className="text-green-500">{task.completions.toLocaleString()}</span>
                    <span>tamamlama</span>
                  </div>
                </div>

                {/* Difficulty */}
                <div className="mb-6">
                  <span className={`text-xs px-3 py-1 rounded-full ${
                    task.difficulty === 'Çok Kolay' ? 'bg-green-500/20 text-green-400' :
                    task.difficulty === 'Kolay' ? 'bg-blue-500/20 text-blue-400' :
                    'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {task.difficulty}
                  </span>
                </div>

                {/* Reward & CTA */}
                <div className="flex items-center justify-between pt-4 border-t border-white/5">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center">
                      <DollarSign className="w-5 h-5 text-green-500" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-400">Ödül</p>
                      <p className="text-xl font-bold text-green-400">₺{task.reward}</p>
                    </div>
                  </div>
                  <Button 
                    size="sm" 
                    className="gradient-primary hover:opacity-90 text-white border-0"
                  >
                    Başvur
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
