import { useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight, Play, Coins, TrendingUp, Shield, Users } from 'lucide-react';

interface HeroProps {
  navigate: (page: string) => void;
}

export function Hero({ navigate }: HeroProps) {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!heroRef.current) return;
      const { clientX, clientY } = e;
      const { width, height } = heroRef.current.getBoundingClientRect();
      const x = (clientX / width - 0.5) * 20;
      const y = (clientY / height - 0.5) * 20;
      
      const elements = heroRef.current.querySelectorAll('.parallax');
      elements.forEach((el) => {
        (el as HTMLElement).style.transform = `translate(${x}px, ${y}px)`;
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section
      id="hero"
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden gradient-hero pt-20"
    >
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Gradient Orbs */}
        <div className="parallax absolute top-20 left-10 w-72 h-72 bg-green-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="parallax absolute bottom-20 right-10 w-96 h-96 bg-emerald-500/15 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="parallax absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-green-400/10 rounded-full blur-3xl" />
        
        {/* Floating Particles */}
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-green-400/30 rounded-full animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${4 + Math.random() * 4}s`,
              }}
            />
          ))}
        </div>

        {/* Grid Pattern */}
        <div 
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: '50px 50px'
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/10 border border-green-500/20 animate-fade-in">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-sm text-green-400 font-medium">Yeni görevler her gün eklendi!</span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight animate-slide-up">
              <span className="text-white">Görev Yap</span>
              <br />
              <span className="bg-gradient-to-r from-green-400 via-emerald-400 to-teal-400 bg-clip-text text-transparent">
                Para Kazan
              </span>
            </h1>

            {/* Description */}
            <p className="text-lg sm:text-xl text-slate-400 max-w-xl mx-auto lg:mx-0 animate-slide-up" style={{ animationDelay: '0.1s' }}>
              Anketler doldur, uygulamalar indir, videolar izle ve görevleri tamamlayarak 
              <span className="text-green-400 font-semibold"> gerçek para kazan!</span> 
              Hemen ücretsiz üye ol, kazanmaya başla.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <Button 
                size="lg" 
                onClick={() => navigate('dashboard')}
                className="gradient-primary hover:opacity-90 text-white border-0 text-lg px-8 py-6 animate-pulse-glow rounded-xl"
              >
                Hemen Başla
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white/20 text-white hover:bg-white/10 text-lg px-8 py-6 rounded-xl"
              >
                <Play className="w-5 h-5 mr-2" />
                Nasıl Çalışır?
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 pt-4 animate-slide-up" style={{ animationDelay: '0.3s' }}>
              <div className="flex items-center gap-2 text-slate-400">
                <Shield className="w-5 h-5 text-green-500" />
                <span className="text-sm">Güvenli Ödeme</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <Users className="w-5 h-5 text-green-500" />
                <span className="text-sm">50K+ Kullanıcı</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <TrendingUp className="w-5 h-5 text-green-500" />
                <span className="text-sm">Anında Çekim</span>
              </div>
            </div>
          </div>

          {/* Right Content - 3D Card Stack */}
          <div className="relative hidden lg:block">
            <div className="relative w-full h-[500px]">
              {/* Main Card */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 glass rounded-3xl p-6 animate-float border border-green-500/30 shadow-2xl shadow-green-500/20">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center">
                      <Coins className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="text-sm text-slate-400">Toplam Kazanç</p>
                      <p className="text-2xl font-bold text-white">₺12,450</p>
                    </div>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-green-500/20 text-green-400 text-xs font-medium">
                    +₺125 bugün
                  </span>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 rounded-xl bg-white/5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                        <span className="text-blue-400 text-lg">📱</span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">Uygulama İndir</p>
                        <p className="text-xs text-slate-400">2 dakika</p>
                      </div>
                    </div>
                    <span className="text-green-400 font-semibold">+₺15</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-xl bg-white/5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                        <span className="text-purple-400 text-lg">📊</span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">Anket Doldur</p>
                        <p className="text-xs text-slate-400">5 dakika</p>
                      </div>
                    </div>
                    <span className="text-green-400 font-semibold">+₺25</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-xl bg-white/5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-orange-500/20 flex items-center justify-center">
                        <span className="text-orange-400 text-lg">▶️</span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">Video İzle</p>
                        <p className="text-xs text-slate-400">30 saniye</p>
                      </div>
                    </div>
                    <span className="text-green-400 font-semibold">+₺5</span>
                  </div>
                </div>

                <Button 
                  onClick={() => navigate('tasks')}
                  className="w-full mt-6 gradient-primary hover:opacity-90 text-white border-0"
                >
                  Görevlere Git
                </Button>
              </div>

              {/* Background Cards */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-[400px] glass rounded-3xl border border-white/10 -rotate-6 opacity-50" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-[400px] glass rounded-3xl border border-white/10 rotate-6 opacity-30" />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Gradient Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-slate-950 to-transparent" />
    </section>
  );
}
