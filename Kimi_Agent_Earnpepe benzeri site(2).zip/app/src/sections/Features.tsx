import { useEffect, useRef, useState } from 'react';
import { 
  Zap, 
  Shield, 
  Clock, 
  Gift, 
  Headphones, 
  Globe,
  CheckCircle2
} from 'lucide-react';

const features = [
  {
    icon: <Zap className="w-7 h-7" />,
    title: 'Anında Onay',
    description: 'Görevlerin otomatik sistem tarafından dakikalar içinde kontrol edilir ve onaylanır.',
    color: 'from-yellow-500 to-amber-500',
  },
  {
    icon: <Shield className="w-7 h-7" />,
    title: 'Güvenli Ödeme',
    description: 'SSL şifreleme ve güvenli ödeme altyapısı ile paranız her zaman güvende.',
    color: 'from-green-500 to-emerald-500',
  },
  {
    icon: <Clock className="w-7 h-7" />,
    title: '7/24 Destek',
    description: 'Uzman destek ekibimiz her an yanınızda. Sorularınızı anında yanıtlıyoruz.',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    icon: <Gift className="w-7 h-7" />,
    title: 'Bonus Sistemi',
    description: 'Günlük giriş bonusu, referans kazancı ve özel etkinliklerle ekstra para kazan.',
    color: 'from-purple-500 to-pink-500',
  },
  {
    icon: <Headphones className="w-7 h-7" />,
    title: 'Kolay Kullanım',
    description: 'Kullanıcı dostu arayüz ile görevleri bul ve tamamla. Teknik bilgi gerekmez.',
    color: 'from-orange-500 to-red-500',
  },
  {
    icon: <Globe className="w-7 h-7" />,
    title: 'Çoklu Ödeme',
    description: 'Papara, PayPal, banka transferi ve kripto para ile çekim yapabilirsin.',
    color: 'from-indigo-500 to-violet-500',
  },
];

const benefits = [
  'Ücretsiz üyelik',
  'Minimum çekim limiti: ₺50',
  'Günlük 100+ yeni görev',
  'Referans başına ₺10 bonus',
  'Anında para çekme',
  'Mobil uyumlu platform',
];

export function Features() {
  const [visibleFeatures, setVisibleFeatures] = useState<number[]>([]);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          features.forEach((_, index) => {
            setTimeout(() => {
              setVisibleFeatures((prev) => [...prev, index]);
            }, index * 100);
          });
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-20 lg:py-32 bg-slate-950 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-green-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-emerald-500/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div>
            <span className="inline-block px-4 py-2 rounded-full bg-green-500/10 text-green-400 text-sm font-medium mb-4">
              Neden GörevYap?
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
              En İyi <span className="text-green-400">Kazanç Platformu</span>
            </h2>
            <p className="text-lg text-slate-400 mb-8">
              GörevYap, Türkiye'nin en güvenilir ve en yüksek ödeme yapan mikro görev platformudur. 
              Binlerce kullanıcı her gün para kazanıyor, sıra sende!
            </p>

            {/* Benefits List */}
            <div className="grid sm:grid-cols-2 gap-4">
              {benefits.map((benefit, index) => (
                <div 
                  key={index} 
                  className="flex items-center gap-3 p-3 rounded-xl bg-slate-900/50 border border-white/5"
                >
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-slate-300 text-sm">{benefit}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Content - Features Grid */}
          <div className="grid sm:grid-cols-2 gap-4">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`group p-6 rounded-2xl bg-slate-900/50 border border-white/5 hover:border-green-500/30 transition-all duration-500 hover:-translate-y-1 ${
                  visibleFeatures.includes(index)
                    ? 'opacity-100 translate-y-0'
                    : 'opacity-0 translate-y-8'
                }`}
              >
                <div className={`inline-flex items-center justify-center w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} mb-4 text-white shadow-lg group-hover:scale-110 transition-transform`}>
                  {feature.icon}
                </div>
                <h3 className="text-lg font-bold text-white mb-2 group-hover:text-green-400 transition-colors">
                  {feature.title}
                </h3>
                <p className="text-slate-400 text-sm leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
