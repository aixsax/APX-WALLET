import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X, Wallet, User, LayoutDashboard } from 'lucide-react';

const navLinks = [
  { name: 'Ana Sayfa', href: '#hero' },
  { name: 'Görevler', href: '#tasks' },
  { name: 'Nasıl Çalışır', href: '#how-it-works' },
  { name: 'SSS', href: '#faq' },
];

interface NavbarProps {
  navigate: (page: string) => void;
}

export function Navbar({ navigate }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-slate-950/90 backdrop-blur-lg border-b border-white/10'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <a href="#hero" className="flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center group-hover:scale-110 transition-transform">
              <Wallet className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
              GörevYap
            </span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.name}
                onClick={() => scrollToSection(link.href)}
                className="text-sm text-slate-300 hover:text-white transition-colors relative group"
              >
                {link.name}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-green-500 group-hover:w-full transition-all duration-300" />
              </button>
            ))}
          </div>

          {/* Desktop CTA Buttons */}
          <div className="hidden lg:flex items-center gap-3">
            <Button
              variant="ghost"
              onClick={() => navigate('dashboard')}
              className="text-slate-300 hover:text-white hover:bg-white/10"
            >
              <User className="w-4 h-4 mr-2" />
              Giriş Yap
            </Button>
            <Button 
              onClick={() => navigate('dashboard')}
              className="gradient-primary hover:opacity-90 text-white border-0"
            >
              <LayoutDashboard className="w-4 h-4 mr-2" />
              Panele Git
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2 text-slate-300 hover:text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden py-4 border-t border-white/10 animate-slide-up">
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <button
                  key={link.name}
                  onClick={() => scrollToSection(link.href)}
                  className="text-left text-slate-300 hover:text-white transition-colors py-2"
                >
                  {link.name}
                </button>
              ))}
              <div className="flex flex-col gap-2 pt-4 border-t border-white/10">
                <Button
                  variant="ghost"
                  onClick={() => navigate('dashboard')}
                  className="justify-start text-slate-300 hover:text-white hover:bg-white/10"
                >
                  <User className="w-4 h-4 mr-2" />
                  Giriş Yap
                </Button>
                <Button 
                  onClick={() => navigate('dashboard')}
                  className="gradient-primary hover:opacity-90 text-white border-0"
                >
                  <LayoutDashboard className="w-4 h-4 mr-2" />
                  Panele Git
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
