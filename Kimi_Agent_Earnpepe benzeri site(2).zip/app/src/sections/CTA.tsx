import { Button } from '@/components/ui/button';
import { ArrowRight, Sparkles, Gift, Zap } from 'lucide-react';

interface CTAProps {
  navigate: (page: string) => void;
}

export function CTA({ navigate }: CTAProps) {
  return (
    <section className="relative py-20 lg:py-32 bg-slate-950 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        {/* Gradient Orbs */}
        <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[500px] h-[500px] bg-green-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-[500px] h-[500px] bg-emerald-500/15 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        
        {/* Grid Pattern */}
        <div 
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: '40px 40px'
          }}
        />
      </div>

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative p-8 lg:p-16 rounded-3xl overflow-hidden">
          {/* Card Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-900 to-green-900/30" />
          <div className="absolute inset-0 border border-green-500/20 rounded-3xl" />
          
          {/* Decorative Elements */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-green-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl" />

          {/* Content */}
          <div className="relative text-center">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/20 border border-green-500/30 mb-8">
              <Gift className="w-4 h-4 text-green-400" />
              <span className="text-sm text-green-400 font-medium">Sınırlı Süreli Fırsat!</span>
            </div>

            {/* Headline */}
            <h2 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-white mb-6">
              Hemen Üye Ol,{' '}
              <span className="bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                10₺ Bonus
              </span>{' '}
              Kazan!
            </h2>

            {/* Description */}
            <p className="text-lg lg:text-xl text-slate-400 max-w-2xl mx-auto mb-10">
              İlk üyeliğine özel hesabına anında 10₺ ekliyoruz. Üstelik ilk görevini tamamladığında 
              ekstra 15₺ daha kazanacaksın. Toplamda 25₺ ile başla!
            </p>

            {/* Benefits */}
            <div className="flex flex-wrap justify-center gap-4 lg:gap-8 mb-10">
              <div className="flex items-center gap-2 text-slate-300">
                <Sparkles className="w-5 h-5 text-yellow-500" />
                <span>10₺ Hoş Geldin Bonusu</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Zap className="w-5 h-5 text-green-500" />
                <span>Anında Onay</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Gift className="w-5 h-5 text-purple-500" />
                <span>Günlük Bonuslar</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                onClick={() => navigate('dashboard')}
                className="gradient-primary hover:opacity-90 text-white border-0 text-lg px-10 py-7 rounded-xl animate-pulse-glow"
              >
                Ücretsiz Kaydol
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>

            {/* Trust Text */}
            <p className="mt-6 text-sm text-slate-500">
              Kredi kartı gerekmez • İptal edilebilir • 50.000+ kullanıcı
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
