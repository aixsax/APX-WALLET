import { useEffect, useRef, useState } from 'react';
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const testimonials = [
  {
    id: 1,
    name: 'Ahmet Yılmaz',
    avatar: '👨‍💼',
    location: 'İstanbul',
    rating: 5,
    text: 'Üniversite öğrencisiyim ve harçlığımı GörevYap\'tan çıkarıyorum. Günde 1-2 saat ayırarak ayda 800-1000₺ kazanıyorum. Kesinlikle tavsiye ederim!',
    earnings: '₺8,450',
    memberSince: '6 ay',
  },
  {
    id: 2,
    name: 'Zeynep Kaya',
    avatar: '👩‍🎓',
    location: 'Ankara',
    rating: 5,
    text: 'Ev hanımıyım ve boş zamanlarımda görev yapıyorum. Ödemeler gerçekten anında hesaba geçiyor. Papara ile çekim yapıyorum, 5 dakika içinde parayı alıyorum.',
    earnings: '₺12,320',
    memberSince: '8 ay',
  },
  {
    id: 3,
    name: 'Mehmet Demir',
    avatar: '👨‍🔧',
    location: 'İzmir',
    rating: 5,
    text: 'İşten arta kalan zamanlarda ek gelir elde ediyorum. Özellikle oyun görevleri çok kazançlı. Bir ayda 1500₺ kazandım, harika bir platform!',
    earnings: '₺15,780',
    memberSince: '1 yıl',
  },
  {
    id: 4,
    name: 'Elif Şahin',
    avatar: '👩‍💻',
    location: 'Bursa',
    rating: 5,
    text: 'Referans sistemi sayesinde ekstra kazanıyorum. Arkadaşlarımı davet ediyorum, onların kazancından %10 bonus alıyorum. Pasif gelir için mükemmel!',
    earnings: '₺9,650',
    memberSince: '5 ay',
  },
  {
    id: 5,
    name: 'Can Özdemir',
    avatar: '🧑‍🎤',
    location: 'Antalya',
    rating: 5,
    text: 'Tatil için para biriktirmek istiyordum, GörevYap sayesinde hedefime ulaştım. Görevler çeşitli ve eğlenceli, sıkılmıyorsunuz.',
    earnings: '₺6,200',
    memberSince: '3 ay',
  },
];

export function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section ref={sectionRef} className="relative py-20 lg:py-32 bg-slate-950 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-green-500/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-green-500/10 text-green-400 text-sm font-medium mb-4">
            Kullanıcı Yorumları
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Onlar <span className="text-green-400">Kazanıyor</span>, Sen de Kazan!
          </h2>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            Binlerce kullanıcı GörevYap ile para kazanıyor. İşte onların hikayeleri...
          </p>
        </div>

        {/* Testimonials Carousel */}
        <div className={`relative transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}>
          {/* Desktop Grid */}
          <div className="hidden lg:grid grid-cols-3 gap-6">
            {testimonials.slice(0, 3).map((testimonial, index) => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} delay={index * 100} />
            ))}
          </div>

          {/* Mobile/Tablet Carousel */}
          <div className="lg:hidden">
            <div className="overflow-hidden">
              <div 
                className="flex transition-transform duration-500 ease-out"
                style={{ transform: `translateX(-${currentIndex * 100}%)` }}
              >
                {testimonials.map((testimonial) => (
                  <div key={testimonial.id} className="w-full flex-shrink-0 px-2">
                    <TestimonialCard testimonial={testimonial} delay={0} />
                  </div>
                ))}
              </div>
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-center gap-4 mt-8">
              <Button
                variant="outline"
                size="icon"
                onClick={prevSlide}
                className="border-white/20 text-white hover:bg-white/10"
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <div className="flex gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === currentIndex ? 'w-6 bg-green-500' : 'bg-white/20'
                    }`}
                  />
                ))}
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={nextSlide}
                className="border-white/20 text-white hover:bg-white/10"
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Second Row Desktop */}
          <div className="hidden lg:grid grid-cols-2 gap-6 mt-6 max-w-4xl mx-auto">
            {testimonials.slice(3, 5).map((testimonial, index) => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} delay={(index + 3) * 100} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

interface TestimonialCardProps {
  testimonial: typeof testimonials[0];
  delay: number;
}

function TestimonialCard({ testimonial, delay }: TestimonialCardProps) {
  return (
    <div 
      className="relative p-6 lg:p-8 rounded-3xl bg-slate-900/50 border border-white/5 hover:border-green-500/30 transition-all duration-500 hover:-translate-y-1 group"
      style={{ animationDelay: `${delay}ms` }}
    >
      {/* Quote Icon */}
      <div className="absolute top-6 right-6 w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center">
        <Quote className="w-5 h-5 text-green-500" />
      </div>

      {/* Rating */}
      <div className="flex gap-1 mb-4">
        {[...Array(testimonial.rating)].map((_, i) => (
          <Star key={i} className="w-4 h-4 fill-yellow-500 text-yellow-500" />
        ))}
      </div>

      {/* Text */}
      <p className="text-slate-300 leading-relaxed mb-6">
        "{testimonial.text}"
      </p>

      {/* Author */}
      <div className="flex items-center justify-between pt-4 border-t border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-2xl">
            {testimonial.avatar}
          </div>
          <div>
            <p className="font-semibold text-white">{testimonial.name}</p>
            <p className="text-sm text-slate-400">{testimonial.location}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs text-slate-400">Toplam Kazanç</p>
          <p className="text-lg font-bold text-green-400">{testimonial.earnings}</p>
        </div>
      </div>

      {/* Member Badge */}
      <div className="absolute -bottom-3 left-6">
        <span className="px-3 py-1 rounded-full bg-green-500/20 text-green-400 text-xs font-medium">
          {testimonial.memberSince} üye
        </span>
      </div>
    </div>
  );
}
