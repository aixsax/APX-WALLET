import { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

const faqs = [
  {
    question: 'GörevYap nedir ve nasıl çalışır?',
    answer: 'GörevYap, kullanıcıların çeşitli görevleri tamamlayarak para kazandığı bir mikro görev platformudur. Anketler doldurabilir, uygulamalar indirebilir, videolar izleyebilir ve sosyal medya görevleri yapabilirsiniz. Her tamamlanan görev için hesabınıza para eklenir ve dilediğiniz zaman çekebilirsiniz.',
  },
  {
    question: 'Üyelik ücretli mi?',
    answer: 'Hayır, GörevYap\'a üye olmak tamamen ücretsizdir. Hiçbir üyelik ücreti ödemeden hemen başlayabilirsiniz. Ayrıca, ilk üyeliğinizde hesabınıza hoş geldin bonusu olarak 10₺ eklenir.',
  },
  {
    question: 'Ne kadar para kazanabilirim?',
    answer: 'Kazancınız tamamen size bağlıdır. Günlük 1-2 saat ayırarak 50-150₺, daha fazla zaman ayırarak 300-500₺ ve üzeri kazanabilirsiniz. Özellikle oyun görevleri ve referans sistemi ile kazancınızı artırabilirsiniz.',
  },
  {
    question: 'Ödemeleri nasıl alabilirim?',
    answer: 'Ödemelerinizi Papara, PayPal, banka transferi (EFT/HAVALE) veya kripto para (USDT) olarak alabilirsiniz. Minimum çekim limiti 50₺\'dir ve ödemeler genellikle birkaç dakika içinde hesabınıza geçer.',
  },
  {
    question: 'Görevler ne kadar sürede onaylanır?',
    answer: 'Çoğu görev otomatik sistem tarafından dakikalar içinde kontrol edilir ve onaylanır. Bazı görevler manuel kontrol gerektirebilir ve bu durumda 24 saat içinde onaylanır. Onaylanan görevlerin ödemesi anında hesabınıza eklenir.',
  },
  {
    question: 'Referans sistemi nasıl işliyor?',
    answer: 'Arkadaşlarınızı davet ettiğinizde, onların kazancından %10 oranında bonus kazanırsınız. Örneğin, davet ettiğiniz bir arkadaşınız 100₺ kazandığında siz de 10₺ bonus alırsınız. Bu bonuslar sınırsızdır, ne kadar çok arkadaş davet ederseniz o kadar çok kazanırsınız.',
  },
  {
    question: 'Hangi cihazlardan kullanabilirim?',
    answer: 'GörevYap\'ı bilgisayar, tablet ve akıllı telefonunuzdan kullanabilirsiniz. Web sitemiz mobil uyumludur ve tüm cihazlarda sorunsuz çalışır. İsterseniz uygulamamızı da indirebilirsiniz.',
  },
  {
    question: 'Yaş sınırı var mı?',
    answer: 'Evet, platformu kullanabilmek için en az 18 yaşında olmanız gerekmektedir. 18 yaş altı kullanıcıların velilerinin onayı ile hesap açması gerekmektedir.',
  },
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-20 lg:py-32 bg-slate-950">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-green-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-green-500/10 text-green-400 text-sm font-medium mb-4">
            Sık Sorulan Sorular
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Merak Ettikleriniz <span className="text-green-400">Cevaplandı</span>
          </h2>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            GörevYap hakkında en çok sorulan sorular ve cevapları. Başka sorunuz varsa destek ekibimize ulaşabilirsiniz.
          </p>
        </div>

        {/* FAQ List */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className={`rounded-2xl border transition-all duration-300 ${
                openIndex === index
                  ? 'bg-slate-900/80 border-green-500/30'
                  : 'bg-slate-900/30 border-white/5 hover:border-white/10'
              }`}
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 text-left"
              >
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                    openIndex === index ? 'bg-green-500/20 text-green-400' : 'bg-white/5 text-slate-400'
                  }`}>
                    <HelpCircle className="w-5 h-5" />
                  </div>
                  <span className={`font-semibold transition-colors ${
                    openIndex === index ? 'text-white' : 'text-slate-300'
                  }`}>
                    {faq.question}
                  </span>
                </div>
                <ChevronDown
                  className={`w-5 h-5 text-slate-400 transition-transform duration-300 ${
                    openIndex === index ? 'rotate-180 text-green-400' : ''
                  }`}
                />
              </button>
              
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <div className="px-6 pb-6 pl-20">
                  <p className="text-slate-400 leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Contact CTA */}
        <div className="mt-12 text-center p-8 rounded-3xl bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/20">
          <p className="text-slate-300 mb-4">
            Başka sorularınız mı var? Destek ekibimiz 7/24 hizmetinizdedir.
          </p>
          <button className="inline-flex items-center gap-2 text-green-400 font-semibold hover:text-green-300 transition-colors">
            Destek ile İletişime Geç
            <span>→</span>
          </button>
        </div>
      </div>
    </section>
  );
}
