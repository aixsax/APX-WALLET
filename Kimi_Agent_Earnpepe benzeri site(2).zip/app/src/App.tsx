import { useState, useEffect } from 'react';
import LandingPage from './pages/LandingPage';
import Dashboard from './pages/Dashboard';
import Tasks from './pages/Tasks';
import Wallet from './pages/Wallet';
import Profile from './pages/Profile';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminTasks from './pages/admin/AdminTasks';
import AdminUsers from './pages/admin/AdminUsers';
import AdminTransactions from './pages/admin/AdminTransactions';
import AdminSettings from './pages/admin/AdminSettings';

function App() {
  const [currentPage, setCurrentPage] = useState('landing');
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
    
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#/', '') || 'landing';
      setCurrentPage(hash);
    };
    
    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigate = (page: string) => {
    window.location.hash = page === 'landing' ? '' : `/${page}`;
    setCurrentPage(page);
  };

  return (
    <div className={`min-h-screen bg-slate-950 text-white transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
      {currentPage === 'landing' && <LandingPage navigate={navigate} />}
      {currentPage === 'dashboard' && <Dashboard navigate={navigate} />}
      {currentPage === 'tasks' && <Tasks navigate={navigate} />}
      {currentPage === 'wallet' && <Wallet navigate={navigate} />}
      {currentPage === 'profile' && <Profile navigate={navigate} />}
      {currentPage === 'admin' && <AdminDashboard navigate={navigate} />}
      {currentPage === 'admin-tasks' && <AdminTasks navigate={navigate} />}
      {currentPage === 'admin-users' && <AdminUsers navigate={navigate} />}
      {currentPage === 'admin-transactions' && <AdminTransactions navigate={navigate} />}
      {currentPage === 'admin-settings' && <AdminSettings navigate={navigate} />}
    </div>
  );
}

export default App;
